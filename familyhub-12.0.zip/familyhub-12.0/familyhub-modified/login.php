<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/funcoes.php";

if (usuarioLogado()) {
    header("Location: escolher_membro.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <script>
        (function(){
            var t = localStorage.getItem('fh-theme');
            var dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', t || (dark ? 'dark' : 'light'));
        })();
    </script>
</head>
<body class="login-body">

<div class="login-container">
    <div class="login-box">
        <div class="login-header">
            <h1>FamilyHub+</h1>
            <p>Sistema de Organização Familiar</p>
        </div>

        <?= exibirAlertas() ?>

        <form action="acoes/login.php" method="POST" class="login-form">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="seu@email.com" required autocomplete="email" maxlength="150">
            </div>
            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="••••••••" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Entrar</button>
        </form>

        <div class="divider"><span>ou</span></div>

        <a href="registro.php" class="btn btn-secondary btn-block btn-outline">Criar nova conta</a>

        <div class="login-footer">
            <p><a href="recuperar_senha.php">Esqueceu sua senha?</a></p>
        </div>
    </div>
</div>

</body>
</html>

<?php
/**
 * Ação: Entrar como um membro da família
 */
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/funcoes.php";
require_once "../includes/conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$id_usuario = (int)$_SESSION['usuario_id'];
$id_membro  = (int)($_GET['id'] ?? 0);

if ($id_membro > 0) {
    // Verificar que o membro pertence ao usuário
    $stmt = $conn->prepare("SELECT id_membro, nome, papel FROM membros WHERE id_membro = ? AND id_usuario = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param("ii", $id_membro, $id_usuario);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($membro = $res->fetch_assoc()) {
            $_SESSION['membro_id']    = $membro['id_membro'];
            $_SESSION['membro_nome']  = $membro['nome'];
            $_SESSION['membro_papel'] = $membro['papel'];
        } else {
            setMensagem('erro', "Perfil inválido.");
            header("Location: ../escolher_membro.php");
            exit;
        }
        $stmt->close();
    }
} else {
    // Entrar sem perfil (admin / sem membro)
    $_SESSION['membro_id']    = null;
    $_SESSION['membro_nome']  = $_SESSION['usuario_nome'];
    $_SESSION['membro_papel'] = 'Admin';
}

header("Location: ../index.php");
exit;

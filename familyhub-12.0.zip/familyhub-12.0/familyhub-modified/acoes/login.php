<?php
/**
 * Ação de Login - FamilyHub+
 */

// Configurar sessão ANTES de session_start()
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

if (usuarioLogado()) {
    header("Location: ../escolher_membro.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../login.php");
    exit;
}

$email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
$senha = $_POST['senha'] ?? '';

if (empty($email) || empty($senha)) {
    setMensagem('erro', "Preencha todos os campos.");
    header("Location: ../login.php");
    exit;
}

if (!validarEmail($email)) {
    setMensagem('erro', "Email inválido.");
    header("Location: ../login.php");
    exit;
}

try {
    // Tabela usuarios: id_usuario, nome, email, senha, data_criacao
    $stmt = $conn->prepare("SELECT id_usuario, nome, senha FROM usuarios WHERE email = ? LIMIT 1");
    if (!$stmt) throw new Exception("Prepare falhou: " . $conn->error);

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (verificarSenha($senha, $user['senha'])) {
            $_SESSION['usuario_id']   = $user['id_usuario'];
            $_SESSION['usuario_nome'] = $user['nome'];
            session_regenerate_id(true);
            $stmt->close();
            header("Location: ../escolher_membro.php");
            exit;
        }
    }

    $stmt->close();
    setMensagem('erro', "Email ou senha incorretos.");

} catch (Exception $e) {
    logErro("Erro no login: " . $e->getMessage());
    setMensagem('erro', "Erro ao processar login. Tente novamente.");
}

header("Location: ../login.php");
exit;

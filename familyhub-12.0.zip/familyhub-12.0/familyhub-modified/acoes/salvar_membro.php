<?php
/**
 * Ação de Salvar Membro - FamilyHub+
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

// Verifica só o usuario_id — membro_id pode estar vazio nesta tela
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../escolher_membro.php");
    exit;
}

$id_usuario      = (int)$_SESSION['usuario_id'];
$nome            = trim($_POST['nome'] ?? '');
$papel           = trim($_POST['papel'] ?? '');
$data_nascimento = trim($_POST['data_nascimento'] ?? '');

$erros = [];

if (empty($nome)) {
    $erros[] = "O nome é obrigatório.";
} elseif (strlen($nome) < 2) {
    $erros[] = "Nome muito curto.";
} elseif (strlen($nome) > 100) {
    $erros[] = "Nome muito longo.";
}

$papeis_validos = ['Pai', 'Mãe', 'Filho(a)', 'Avô/Avó', 'Outro'];
if (empty($papel) || !in_array($papel, $papeis_validos)) {
    $erros[] = "Papel inválido.";
}

if (empty($data_nascimento)) {
    $erros[] = "A data de nascimento é obrigatória.";
} else {
    $dObj = DateTime::createFromFormat('Y-m-d', $data_nascimento);
    if (!$dObj || $dObj->format('Y-m-d') !== $data_nascimento) {
        $erros[] = "Data inválida.";
    } elseif ($dObj > new DateTime()) {
        $erros[] = "A data não pode ser futura.";
    }
}

if (!empty($erros)) {
    setMensagem('erro', implode("<br>", $erros));
    header("Location: ../escolher_membro.php");
    exit;
}

$id_membro = isset($_POST['id_membro']) ? (int)$_POST['id_membro'] : 0;

try {
    if ($id_membro > 0) {
        $stmt = $conn->prepare("UPDATE membros SET nome=?, papel=?, data_nascimento=? WHERE id_membro=? AND id_usuario=?");
        if (!$stmt) throw new Exception("Prepare falhou: " . $conn->error);
        $stmt->bind_param("sssii", $nome, $papel, $data_nascimento, $id_membro, $id_usuario);
        if (!$stmt->execute()) throw new Exception("Execute falhou: " . $stmt->error);
        $stmt->close();
        // Atualiza sessão se editou o membro ativo
        if (isset($_SESSION['membro_id']) && (int)$_SESSION['membro_id'] === $id_membro) {
            $_SESSION['membro_nome']  = $nome;
            $_SESSION['membro_papel'] = $papel;
        }
        // Notificação
        $autorNome = $_SESSION['membro_nome'] ?? $_SESSION['usuario_nome'] ?? 'Alguém';
        $msg = "✏️ $autorNome atualizou o membro \"$nome\" ($papel)";
        $sn = $conn->prepare("INSERT INTO notificacoes (mensagem, id_usuario) VALUES (?, ?)");
        if ($sn) { $sn->bind_param("si", $msg, $id_usuario); $sn->execute(); $sn->close(); }
        setMensagem('sucesso', "Membro atualizado com sucesso!");
    } else {
        $stmt = $conn->prepare("INSERT INTO membros (nome, papel, data_nascimento, id_usuario) VALUES (?, ?, ?, ?)");
        if (!$stmt) throw new Exception("Prepare falhou: " . $conn->error);
        $stmt->bind_param("sssi", $nome, $papel, $data_nascimento, $id_usuario);
        if (!$stmt->execute()) throw new Exception("Execute falhou: " . $stmt->error);
        $stmt->close();
        // Notificação
        $autorNome = $_SESSION['usuario_nome'] ?? 'Alguém';
        $msg = "👤 $autorNome adicionou o membro \"$nome\" ($papel) à família";
        $sn = $conn->prepare("INSERT INTO notificacoes (mensagem, id_usuario) VALUES (?, ?)");
        if ($sn) { $sn->bind_param("si", $msg, $id_usuario); $sn->execute(); $sn->close(); }
        setMensagem('sucesso', "Membro adicionado com sucesso!");
    }
} catch (Exception $e) {
    logErro("Erro ao salvar membro: " . $e->getMessage());
    setMensagem('erro', "Erro ao salvar membro. Tente novamente.");
}

header("Location: ../escolher_membro.php");
exit;

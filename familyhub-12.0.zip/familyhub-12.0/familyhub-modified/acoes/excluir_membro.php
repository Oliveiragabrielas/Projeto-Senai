<?php
/**
 * Ação: Excluir Membro - FamilyHub+
 */
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

// Verifica só o usuario_id
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../escolher_membro.php");
    exit;
}

$id_usuario = (int)$_SESSION['usuario_id'];
$id_membro  = (int)($_POST['id_membro'] ?? 0);

if ($id_membro <= 0) {
    setMensagem('erro', "Membro inválido.");
    header("Location: ../escolher_membro.php");
    exit;
}

$stmt = $conn->prepare("SELECT nome FROM membros WHERE id_membro = ? AND id_usuario = ? LIMIT 1");
if (!$stmt) {
    setMensagem('erro', "Erro ao processar.");
    header("Location: ../escolher_membro.php");
    exit;
}
$stmt->bind_param("ii", $id_membro, $id_usuario);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    setMensagem('erro', "Membro não encontrado.");
    header("Location: ../escolher_membro.php");
    exit;
}
$nomeMembro = $res->fetch_assoc()['nome'];
$stmt->close();

// Se era o membro ativo, limpa da sessão
if (isset($_SESSION['membro_id']) && (int)$_SESSION['membro_id'] === $id_membro) {
    unset($_SESSION['membro_id'], $_SESSION['membro_nome'], $_SESSION['membro_papel']);
}

$del = $conn->prepare("DELETE FROM membros WHERE id_membro = ? AND id_usuario = ?");
if ($del) {
    $del->bind_param("ii", $id_membro, $id_usuario);
    if ($del->execute()) {
        setMensagem('sucesso', "\"$nomeMembro\" removido com sucesso.");
    } else {
        setMensagem('erro', "Erro ao excluir membro.");
    }
    $del->close();
} else {
    setMensagem('erro', "Erro ao processar exclusão.");
}

header("Location: ../escolher_membro.php");
exit;

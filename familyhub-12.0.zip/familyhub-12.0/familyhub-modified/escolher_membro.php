<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/funcoes.php";
require_once "includes/conexao.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Limpa seleção para permitir troca
unset($_SESSION['membro_id'], $_SESSION['membro_nome'], $_SESSION['membro_papel']);

$id_usuario = (int)$_SESSION['usuario_id'];

$membros = [];
$stmt = $conn->prepare("SELECT * FROM membros WHERE id_usuario = ? ORDER BY criado_em ASC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $membros[] = $row;
    $stmt->close();
}

function emojiPapel($papel) {
    return ['Pai'=>'👨','Mãe'=>'👩','Filho(a)'=>'🧒','Avô/Avó'=>'👴','Outro'=>'👤'][$papel] ?? '👤';
}
function gradientePapel($papel) {
    return [
        'Pai'     => 'linear-gradient(135deg,#6366f1,#4f46e5)',
        'Mãe'     => 'linear-gradient(135deg,#ec4899,#db2777)',
        'Filho(a)'=> 'linear-gradient(135deg,#22c55e,#16a34a)',
        'Avô/Avó' => 'linear-gradient(135deg,#f59e0b,#d97706)',
        'Outro'   => 'linear-gradient(135deg,#a78bfa,#7c3aed)',
    ][$papel] ?? 'linear-gradient(135deg,#a78bfa,#7c3aed)';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quem está usando? - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ── Layout geral ─────────────────────────────────── */
        .escolher-wrap {
            min-height: 100vh;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 32px 20px;
        }
        .escolher-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .escolher-header h1 {
            font-family: var(--font-display);
            font-size: 2.2rem;
            font-weight: 700;
            color: var(--accent);
            letter-spacing: -0.5px;
            text-shadow: 0 0 28px var(--accent-glow);
            margin-bottom: 6px;
        }
        .escolher-header p {
            color: var(--text-secondary);
            font-size: 1rem;
        }

        /* ── Grid de perfis ───────────────────────────────── */
        .perfis-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            margin-bottom: 36px;
        }

        /* ── Card de perfil ───────────────────────────────── */
        .perfil-card {
            width: 168px;
            border-radius: 20px;
            border: 1px solid var(--border);
            background: var(--bg-card);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: transform .22s, box-shadow .22s, border-color .22s;
            position: relative;
        }
        .perfil-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 40px rgba(0,0,0,0.3);
            border-color: var(--border-strong);
        }

        /* Banner + avatar */
        .pc-top {
            position: relative;
            height: 96px;
            flex-shrink: 0;
        }
        .pc-banner {
            position: absolute;
            inset: 0;
            height: 60px;
        }
        .pc-avatar {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            border: 3px solid var(--bg-base, #0e0a1a);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            font-weight: 800;
            color: #fff;
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 4px 16px rgba(0,0,0,0.3);
        }

        /* Info */
        .pc-body {
            padding: 8px 12px 12px;
            text-align: center;
            flex: 1;
        }
        .pc-nome {
            font-family: var(--font-display);
            font-size: 0.9rem;
            font-weight: 700;
            margin-bottom: 3px;
            line-height: 1.3;
        }
        .pc-papel {
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .06em;
            color: var(--accent);
            margin-bottom: 2px;
        }
        .pc-idade {
            font-size: 0.75rem;
            color: var(--text-muted);
        }

        /* Botão principal: entrar */
        .pc-entrar {
            display: block;
            margin: 10px 12px 0;
            padding: 8px;
            border-radius: 10px;
            background: var(--accent);
            color: #1a0a3e;
            font-weight: 700;
            font-size: 0.82rem;
            text-align: center;
            text-decoration: none;
            transition: opacity .18s, transform .18s;
        }
        .pc-entrar:hover { opacity: .88; transform: scale(1.02); }

        /* Rodapé editar/excluir */
        .pc-footer {
            display: flex;
            border-top: 1px solid var(--border);
            margin-top: 10px;
        }
        .pc-footer button,
        .pc-footer a {
            flex: 1;
            padding: 8px 4px;
            font-size: 0.75rem;
            font-weight: 600;
            background: none;
            border: none;
            cursor: pointer;
            color: var(--text-muted);
            transition: background .15s, color .15s;
            text-decoration: none;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
        }
        .pc-footer button:hover { background: rgba(255,255,255,.05); color: var(--text-primary); }
        .pc-footer .pc-del:hover { background: rgba(239,68,68,.1); color: #ef4444; }
        .pc-footer .sep { width: 1px; background: var(--border); flex: 0; }

        /* ── Card de adicionar ────────────────────────────── */
        .perfil-add {
            width: 168px;
            min-height: 230px;
            border-radius: 20px;
            border: 2px dashed var(--border);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 10px;
            cursor: pointer;
            transition: border-color .2s, background .2s, color .2s;
            color: var(--text-muted);
            background: transparent;
        }
        .perfil-add:hover {
            border-color: var(--accent);
            background: var(--bg-card);
            color: var(--accent);
        }
        .perfil-add-icon { font-size: 2.2rem; display: block; }
        .perfil-add-label { font-size: 0.85rem; font-weight: 700; display: block; }

        /* ── Footer logout ────────────────────────────────── */
        .escolher-footer {
            font-size: 0.83rem;
            color: var(--text-muted);
            text-align: center;
        }
        .escolher-footer a {
            color: var(--text-muted);
            text-decoration: none;
            transition: color .15s;
        }
        .escolher-footer a:hover { color: var(--accent); }

        /* ── Alertas ──────────────────────────────────────── */
        .alertas-wrap { width: 100%; max-width: 600px; margin-bottom: 16px; }

        /* ── Drawer lateral ───────────────────────────────── */
        .drawer-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(3px);
            z-index: 1000;
        }
        .drawer-overlay.active { display: block; }
        .drawer {
            position: fixed;
            top: 0; right: 0;
            width: 100%; max-width: 380px;
            height: 100%;
            background: var(--bg-surface);
            border-left: 1px solid var(--border);
            z-index: 1001;
            padding: 36px 28px;
            overflow-y: auto;
            transform: translateX(110%);
            transition: transform .3s cubic-bezier(.4,0,.2,1);
            box-shadow: -8px 0 40px rgba(0,0,0,.3);
        }
        .drawer.active { transform: translateX(0); }
        .drawer-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 28px;
        }
        .drawer-header h2 {
            font-family: var(--font-display);
            font-size: 1.15rem;
            font-weight: 700;
        }
        .drawer-close {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--text-muted);
            padding: 4px 8px;
            border-radius: 8px;
            transition: background .15s, color .15s;
        }
        .drawer-close:hover { background: rgba(255,255,255,.07); color: var(--text-primary); }

        /* ── Confirm exclusão ─────────────────────────────── */
        .confirm-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.65);
            z-index: 1100;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .confirm-overlay.active { display: flex; }
        .confirm-box {
            background: var(--bg-surface);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 36px 28px;
            max-width: 360px;
            width: 100%;
            text-align: center;
            box-shadow: var(--shadow-lg);
            animation: popModal .25s cubic-bezier(.17,.67,.33,1.25);
        }
        @keyframes popModal {
            from { opacity:0; transform:scale(.9) translateY(20px); }
            to   { opacity:1; transform:scale(1)  translateY(0); }
        }
        .confirm-emoji { font-size: 2.8rem; margin-bottom: 12px; }
        .confirm-box h3 { font-family: var(--font-display); font-size: 1.1rem; margin-bottom: 8px; }
        .confirm-box p  { color: var(--text-secondary); font-size: 0.87rem; line-height: 1.6; margin-bottom: 24px; }
        .confirm-box strong { color: var(--accent); }
        .confirm-actions { display: flex; gap: 10px; justify-content: center; }
        .btn-del-confirm { background: #ef4444 !important; border-color: #ef4444 !important; color: #fff !important; }

        /* Override body flex that comes from style.css */
        body {
            display: block !important;
        }

        @media (max-width: 480px) {
            .perfil-card, .perfil-add { width: 140px; }
            .drawer { max-width: 100%; }
        }
    </style>
</head>
<body>

<div class="escolher-wrap">

    <div class="escolher-header">
        <h1>FamilyHub+</h1>
        <p>Quem está usando agora?</p>
    </div>

    <div class="alertas-wrap"><?= exibirAlertas() ?></div>

    <div class="perfis-grid">

        <?php foreach ($membros as $m):
            $inicial = mb_strtoupper(mb_substr($m['nome'], 0, 1, 'UTF-8'), 'UTF-8');
            $grad    = gradientePapel($m['papel']);
            $idade   = '';
            if (!empty($m['data_nascimento'])) {
                $anos  = (new DateTime($m['data_nascimento']))->diff(new DateTime())->y;
                $idade = $anos . ' ano' . ($anos !== 1 ? 's' : '');
            }
        ?>
        <div class="perfil-card">
            <!-- Banner + avatar -->
            <div class="pc-top">
                <div class="pc-banner" style="background:<?= $grad ?>;"></div>
                <div class="pc-avatar" style="background:<?= $grad ?>;"><?= $inicial ?></div>
            </div>

            <!-- Info -->
            <div class="pc-body">
                <div class="pc-nome"><?= esc($m['nome']) ?></div>
                <div class="pc-papel"><?= emojiPapel($m['papel']) ?> <?= esc($m['papel']) ?></div>
                <?php if ($idade): ?><div class="pc-idade">🎂 <?= $idade ?></div><?php endif; ?>
            </div>

            <!-- Botão entrar -->
            <a href="acoes/entrar_como.php?id=<?= (int)$m['id_membro'] ?>" class="pc-entrar">
                Entrar →
            </a>

            <!-- Editar / Excluir -->
            <div class="pc-footer">
                <button onclick="abrirEditar(<?= (int)$m['id_membro'] ?>, '<?= addslashes(esc($m['nome'])) ?>', '<?= esc($m['papel']) ?>', '<?= esc($m['data_nascimento']) ?>')">
                    ✏️ Editar
                </button>
                <span class="sep"></span>
                <button class="pc-del" onclick="confirmarExclusao(<?= (int)$m['id_membro'] ?>, '<?= addslashes(esc($m['nome'])) ?>')">
                    🗑️ Excluir
                </button>
            </div>
        </div>
        <?php endforeach; ?>

        <!-- Card adicionar -->
        <div class="perfil-add" onclick="abrirAdicionar()">
            <span class="perfil-add-icon">➕</span>
            <span class="perfil-add-label">Adicionar</span>
        </div>

    </div>

    <div class="escolher-footer">
        <a href="logout.php">🚪 Sair da conta</a>
    </div>

</div>

<!-- ── Overlay do drawer ─────────────────────────────────── -->
<div class="drawer-overlay" id="drawerOverlay" onclick="fecharDrawer()"></div>

<!-- ── Drawer Adicionar / Editar ────────────────────────── -->
<div class="drawer" id="drawer">
    <div class="drawer-header">
        <h2 id="drawer-titulo">➕ Novo membro</h2>
        <button class="drawer-close" onclick="fecharDrawer()">✕</button>
    </div>
    <form action="acoes/salvar_membro.php" method="POST">
        <input type="hidden" name="id_membro" id="f-id" value="">
        <div class="form-group">
            <label for="f-nome">Nome completo *</label>
            <input type="text" id="f-nome" name="nome" placeholder="Ex: João da Silva" required maxlength="100">
        </div>
        <div class="form-group">
            <label for="f-papel">Papel *</label>
            <select id="f-papel" name="papel" required>
                <option value="">Selecione...</option>
                <option value="Pai">👨 Pai</option>
                <option value="Mãe">👩 Mãe</option>
                <option value="Filho(a)">🧒 Filho(a)</option>
                <option value="Avô/Avó">👴 Avô/Avó</option>
                <option value="Outro">👤 Outro</option>
            </select>
        </div>
        <div class="form-group">
            <label for="f-data">Data de nascimento *</label>
            <input type="date" id="f-data" name="data_nascimento" required max="<?= date('Y-m-d') ?>">
        </div>
        <div style="display:flex;gap:10px;margin-top:20px;">
            <button type="button" class="btn" onclick="fecharDrawer()" style="flex:1;">Cancelar</button>
            <button type="submit" class="btn btn-primary" id="drawer-submit" style="flex:2;">➕ Adicionar</button>
        </div>
    </form>
</div>

<!-- ── Confirm excluir ───────────────────────────────────── -->
<div class="confirm-overlay" id="confirmOverlay">
    <div class="confirm-box">
        <div class="confirm-emoji">🗑️</div>
        <h3>Remover perfil?</h3>
        <p>Tem certeza que quer remover <strong id="confirm-nome"></strong>?<br>
        Todas as atividades deste membro também serão apagadas.</p>
        <form action="acoes/excluir_membro.php" method="POST">
            <input type="hidden" name="id_membro" id="confirm-id">
            <div class="confirm-actions">
                <button type="button" class="btn" onclick="fecharConfirm()">Cancelar</button>
                <button type="submit" class="btn btn-primary btn-del-confirm">Remover</button>
            </div>
        </form>
    </div>
</div>

<script>
(function(){
    const t = localStorage.getItem('fh-theme');
    const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute('data-theme', t || (dark ? 'dark' : 'light'));
})();

function abrirAdicionar() {
    document.getElementById('drawer-titulo').textContent = '➕ Novo membro';
    document.getElementById('drawer-submit').textContent = '➕ Adicionar';
    document.getElementById('f-id').value    = '';
    document.getElementById('f-nome').value  = '';
    document.getElementById('f-papel').value = '';
    document.getElementById('f-data').value  = '';
    document.getElementById('drawer').classList.add('active');
    document.getElementById('drawerOverlay').classList.add('active');
    setTimeout(() => document.getElementById('f-nome').focus(), 300);
}

function abrirEditar(id, nome, papel, data) {
    document.getElementById('drawer-titulo').textContent = '✏️ Editar membro';
    document.getElementById('drawer-submit').textContent = '💾 Salvar';
    document.getElementById('f-id').value    = id;
    document.getElementById('f-nome').value  = nome;
    document.getElementById('f-papel').value = papel;
    document.getElementById('f-data').value  = data;
    document.getElementById('drawer').classList.add('active');
    document.getElementById('drawerOverlay').classList.add('active');
    setTimeout(() => document.getElementById('f-nome').focus(), 300);
}

function fecharDrawer() {
    document.getElementById('drawer').classList.remove('active');
    document.getElementById('drawerOverlay').classList.remove('active');
}

function confirmarExclusao(id, nome) {
    document.getElementById('confirm-id').value = id;
    document.getElementById('confirm-nome').textContent = nome;
    document.getElementById('confirmOverlay').classList.add('active');
}

function fecharConfirm() {
    document.getElementById('confirmOverlay').classList.remove('active');
}

document.getElementById('confirmOverlay').addEventListener('click', function(e) {
    if (e.target === this) fecharConfirm();
});
</script>
</body>
</html>

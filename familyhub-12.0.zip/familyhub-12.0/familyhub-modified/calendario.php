<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$atividades = [];
$stmt = $conn->prepare("SELECT a.*, m.nome as nome_membro FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? ORDER BY a.data ASC, a.horario ASC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $atividades[] = $row;
    $stmt->close();
}

// Agrupar por data
$porData = [];
foreach ($atividades as $a) {
    $porData[$a['data']][] = $a;
}

// Mes/ano via GET ou atual
$hoje     = new DateTime();
$mesAtual = isset($_GET['mes']) ? (int)$_GET['mes'] : (int)$hoje->format('m');
$anoAtual = isset($_GET['ano']) ? (int)$_GET['ano'] : (int)$hoje->format('Y');
$mesAtual = max(1, min(12, $mesAtual));
$anoAtual = max(2000, min(2100, $anoAtual));

$dtMes       = new DateTime("$anoAtual-$mesAtual-01");
$primeiroDia = (int)$dtMes->format('w');
$totalDias   = (int)$dtMes->format('t');

$dtAnterior = (clone $dtMes)->modify('-1 month');
$dtProximo  = (clone $dtMes)->modify('+1 month');

$meses_pt = ['01'=>'Janeiro','02'=>'Fevereiro','03'=>'Março','04'=>'Abril','05'=>'Maio',
             '06'=>'Junho','07'=>'Julho','08'=>'Agosto','09'=>'Setembro','10'=>'Outubro',
             '11'=>'Novembro','12'=>'Dezembro'];
$nomeMes  = $meses_pt[str_pad($mesAtual, 2, '0', STR_PAD_LEFT)] . ' de ' . $anoAtual;

$atividadesMes = array_filter($atividades, function($a) use ($mesAtual, $anoAtual) {
    $d = new DateTime($a['data']);
    return (int)$d->format('m') === $mesAtual && (int)$d->format('Y') === $anoAtual;
});
$atividadesMes = array_values($atividadesMes);

$hojeStr = $hoje->format('Y-m-d');
$diasSemana = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>📅 Calendário</h1>
        <p class="subtitle">Visualize e organize as atividades da família por data</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="cal-layout">

        <!-- GRADE DO CALENDÁRIO -->
        <div class="cal-card">

            <div class="cal-nav">
                <a href="?mes=<?= $dtAnterior->format('m') ?>&ano=<?= $dtAnterior->format('Y') ?>" class="cal-nav-btn">‹</a>
                <h2 class="cal-mes-titulo"><?= $nomeMes ?></h2>
                <a href="?mes=<?= $dtProximo->format('m') ?>&ano=<?= $dtProximo->format('Y') ?>" class="cal-nav-btn">›</a>
            </div>

            <div class="cal-grid">
                <?php foreach ($diasSemana as $ds): ?>
                    <div class="cal-dow"><?= $ds ?></div>
                <?php endforeach; ?>

                <?php for ($i = 0; $i < $primeiroDia; $i++): ?>
                    <div class="cal-day cal-day--empty"></div>
                <?php endfor; ?>

                <?php for ($dia = 1; $dia <= $totalDias; $dia++):
                    $dataStr = sprintf('%04d-%02d-%02d', $anoAtual, $mesAtual, $dia);
                    $temAtiv = isset($porData[$dataStr]);
                    $isHoje  = ($dataStr === $hojeStr);
                    $qtd     = $temAtiv ? count($porData[$dataStr]) : 0;
                    $cls     = 'cal-day' . ($isHoje ? ' cal-day--hoje' : '') . ($temAtiv ? ' cal-day--ativo' : '');
                ?>
                    <div class="<?= $cls ?>" data-data="<?= $dataStr ?>">
                        <span class="cal-day-num"><?= $dia ?></span>
                        <?php if ($temAtiv): ?>
                            <div class="cal-day-dots">
                                <?php
                                $statusVisto = [];
                                foreach ($porData[$dataStr] as $ev) {
                                    $st = strtolower($ev['status']);
                                    if (!in_array($st, $statusVisto)) {
                                        echo "<span class=\"cal-dot cal-dot--$st\"></span>";
                                        $statusVisto[] = $st;
                                    }
                                }
                                ?>
                            </div>
                            <span class="cal-day-count"><?= $qtd ?></span>
                        <?php endif; ?>
                    </div>
                <?php endfor; ?>
            </div>

            <div class="cal-legenda">
                <span class="cal-legenda-item"><span class="cal-dot cal-dot--pendente"></span> Pendente</span>
                <span class="cal-legenda-item"><span class="cal-dot cal-dot--processo"></span> Em Processo</span>
                <span class="cal-legenda-item"><span class="cal-dot cal-dot--concluída"></span> Concluída</span>
            </div>
        </div>

        <!-- PAINEL LATERAL -->
        <div class="cal-sidebar">
            <div class="cal-sidebar-header">
                <h3 id="cal-sidebar-titulo">Atividades em <?= $meses_pt[str_pad($mesAtual, 2, '0', STR_PAD_LEFT)] ?></h3>
                <span class="cal-sidebar-count"><?= count($atividadesMes) ?></span>
            </div>

            <?php if (empty($atividadesMes)): ?>
                <div class="empty-state" style="padding:32px 16px;">
                    <p>Nenhuma atividade neste mês.</p>
                    <a href="atividades.php" class="btn btn-primary btn-sm">+ Cadastrar</a>
                </div>
            <?php else: ?>
                <div class="cal-eventos" id="cal-eventos-lista">
                    <?php
                    $diaAtual = null;
                    foreach ($atividadesMes as $a):
                        $diaNum   = date('d', strtotime($a['data']));
                        $diaNome  = $diasSemana[date('w', strtotime($a['data']))];
                        $dataGrp  = $a['data'];
                        if ($diaNum !== $diaAtual):
                            if ($diaAtual !== null) echo '</div>';
                            $diaAtual = $diaNum;
                    ?>
                        <div class="cal-evento-grupo" data-dia="<?= $dataGrp ?>">
                        <div class="cal-evento-dia-header">
                            <span class="cal-evento-dia-num"><?= $diaNum ?></span>
                            <span class="cal-evento-dia-nome"><?= $diaNome ?></span>
                        </div>
                    <?php endif; ?>

                        <div class="cal-evento-item cal-evento--<?= strtolower(esc($a['status'])) ?>">
                            <div class="cal-evento-hora"><?= date('H:i', strtotime($a['horario'])) ?></div>
                            <div class="cal-evento-body">
                                <strong><?= esc($a['descricao']) ?></strong>
                                <span class="cal-evento-meta"><?= esc($a['tipo']) ?> &bull; <?= esc($a['nome_membro']) ?></span>
                            </div>
                            <span class="badge badge-<?= strtolower(esc($a['status'])) ?>"><?= esc($a['status']) ?></span>
                        </div>

                    <?php endforeach; ?>
                    <?php if ($diaAtual !== null) echo '</div>'; ?>
                </div>
            <?php endif; ?>

            <div class="cal-sidebar-footer">
                <a href="atividades.php" class="btn btn-primary btn-block">+ Nova Atividade</a>
            </div>
        </div>

    </div>
</main>

<script>
document.querySelectorAll('.cal-day--ativo').forEach(cell => {
    cell.style.cursor = 'pointer';
    cell.addEventListener('click', () => {
        document.querySelectorAll('.cal-day--selected').forEach(c => c.classList.remove('cal-day--selected'));
        cell.classList.add('cal-day--selected');
        const data = cell.dataset.data;
        const grupo = document.querySelector(`.cal-evento-grupo[data-dia="${data}"]`);
        if (grupo) {
            grupo.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            grupo.classList.add('cal-evento-grupo--highlight');
            setTimeout(() => grupo.classList.remove('cal-evento-grupo--highlight'), 1800);
        }
    });
});
</script>
</body>
</html>
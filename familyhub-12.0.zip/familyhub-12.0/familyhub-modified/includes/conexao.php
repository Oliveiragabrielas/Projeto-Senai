<?php
/**
 * Conexão com o Banco de Dados - FamilyHub+
 */

require_once __DIR__ . '/config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    error_log("Erro de conexão: " . $conn->connect_error);
    if (DEBUG_MODE) {
        die("Erro de conexão: " . $conn->connect_error);
    } else {
        die("Erro ao conectar com o banco de dados. Tente novamente mais tarde.");
    }
}

$conn->set_charset(DB_CHARSET);

function fecharConexao() {
    global $conn;
    if ($conn) $conn->close();
}
register_shutdown_function('fecharConexao');

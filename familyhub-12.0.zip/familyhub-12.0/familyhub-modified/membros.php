<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('FAMILYHUB_SESSION');
    session_start();
}
header("Location: escolher_membro.php");
exit;

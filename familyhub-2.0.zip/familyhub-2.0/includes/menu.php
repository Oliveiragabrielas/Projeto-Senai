<?php
/**
 * Menu lateral - FamilyHub
 */

$totalNotif = 0;

if (isset($_SESSION['usuario_id'], $conn)) {
    $uid = (int)$_SESSION['usuario_id'];
    $q = $conn->prepare("SELECT COUNT(*) as total FROM notificacoes WHERE id_usuario = ? AND lida = 0");
    if ($q) {
        $q->bind_param("i", $uid);
        $q->execute();
        $totalNotif = (int)$q->get_result()->fetch_assoc()['total'];
        $q->close();
    }
}

$pg = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
    <h2>FamilyHub</h2>
    <nav>
        <a href="index.php"       class="<?= $pg === 'index.php'       ? 'active' : '' ?>"><span class="icon">📊</span> Dashboard</a>
        <a href="membros.php"     class="<?= $pg === 'membros.php'     ? 'active' : '' ?>"><span class="icon">👥</span> Membros</a>
        <a href="atividades.php"  class="<?= $pg === 'atividades.php'  ? 'active' : '' ?>"><span class="icon">📋</span> Atividades</a>
        <a href="calendario.php"  class="<?= $pg === 'calendario.php'  ? 'active' : '' ?>"><span class="icon">📅</span> Calendário</a>
        <a href="notificacoes.php" class="<?= $pg === 'notificacoes.php' ? 'active' : '' ?>">
            <span class="icon">🔔</span> Notificações
            <?php if ($totalNotif > 0): ?>
                <span class="badge"><?= $totalNotif ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php" class="logout"><span class="icon">🚪</span> Sair</a>
    </nav>
</div>

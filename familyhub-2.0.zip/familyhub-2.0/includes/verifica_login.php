<?php
/**
 * Verificação de Login - FamilyHub
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once __DIR__ . '/funcoes.php';

if (!usuarioLogado()) {
    header("Location: login.php");
    exit;
}

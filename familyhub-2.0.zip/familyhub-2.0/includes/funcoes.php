<?php
/**
 * Funções Auxiliares - FamilyHub
 */

function usuarioLogado() {
    return isset($_SESSION['usuario_id']);
}

function esc($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

function formatarData($data) {
    if (empty($data)) return '';
    $d = DateTime::createFromFormat('Y-m-d', $data);
    return $d ? $d->format('d/m/Y') : esc($data);
}

function setMensagem($tipo, $mensagem) {
    $_SESSION['mensagem_' . $tipo] = $mensagem;
}

function getMensagem($tipo) {
    $msg = $_SESSION['mensagem_' . $tipo] ?? null;
    if ($msg !== null) unset($_SESSION['mensagem_' . $tipo]);
    return $msg;
}

function exibirAlertas() {
    $html  = '';
    $tipos = ['sucesso' => 'success', 'erro' => 'error', 'aviso' => 'warning', 'info' => 'info'];
    foreach ($tipos as $tipo => $classe) {
        $msg = getMensagem($tipo);
        if ($msg) {
            $html .= '<div class="alert alert-' . $classe . '">'
                   . strip_tags($msg, '<br><a>')
                   . '</div>';
        }
    }
    return $html;
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function hashSenha($senha) {
    return password_hash($senha, PASSWORD_DEFAULT);
}

function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

function logErro($msg, $ctx = []) {
    $log = date('Y-m-d H:i:s') . ' - ' . $msg;
    if (!empty($ctx)) $log .= ' | ' . json_encode($ctx);
    error_log($log);
}

<?php
/**
 * Ação de Salvar Atividade - FamilyHub
 * Tipos válidos: 'Escolar', 'Esporte', 'Social', 'Casa', 'Saude', 'Outro' (conforme ENUM no banco)
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/verifica_login.php";
require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../atividades.php");
    exit;
}

$id_usuario = (int)$_SESSION['usuario_id'];
$descricao  = trim($_POST['descricao'] ?? '');
$tipo       = trim($_POST['tipo'] ?? '');
$data       = trim($_POST['data'] ?? '');
$horario    = trim($_POST['horario'] ?? '');
$prioridade = trim($_POST['prioridade'] ?? 'Média');
$status     = trim($_POST['status'] ?? 'Pendente');
$id_membro  = filter_var($_POST['id_membro'] ?? 0, FILTER_VALIDATE_INT);

$erros = [];

if (empty($descricao)) {
    $erros[] = "A descrição é obrigatória.";
} elseif (strlen($descricao) > 500) {
    $erros[] = "Descrição muito longa.";
}

// Valores exatamente iguais ao ENUM do banco
$tipos_validos = ['Escolar', 'Esporte', 'Social', 'Casa', 'Saude', 'Outro'];
if (empty($tipo) || !in_array($tipo, $tipos_validos)) {
    $erros[] = "Tipo inválido.";
}

if (empty($data)) {
    $erros[] = "A data é obrigatória.";
} else {
    $dObj = DateTime::createFromFormat('Y-m-d', $data);
    if (!$dObj || $dObj->format('Y-m-d') !== $data) {
        $erros[] = "Data inválida.";
    }
}

if (empty($horario)) {
    $erros[] = "O horário é obrigatório.";
}

$prioridades_validas = ['Baixa', 'Média', 'Alta'];
if (!in_array($prioridade, $prioridades_validas)) {
    $prioridade = 'Média';
}

$status_validos = ['Pendente', 'Processo', 'Concluída'];
if (!in_array($status, $status_validos)) {
    $erros[] = "Status inválido.";
}

if ($id_membro === false || $id_membro <= 0) {
    $erros[] = "Selecione um membro.";
}

if (!empty($erros)) {
    setMensagem('erro', implode("<br>", $erros));
    header("Location: ../atividades.php");
    exit;
}

try {
    // Garantir que o membro pertence ao usuário logado
    $sv = $conn->prepare("SELECT id_membro FROM membros WHERE id_membro = ? AND id_usuario = ?");
    if (!$sv) throw new Exception("Prepare falhou: " . $conn->error);
    $sv->bind_param("ii", $id_membro, $id_usuario);
    $sv->execute();
    if ($sv->get_result()->num_rows === 0) {
        $sv->close();
        throw new Exception("Membro não autorizado.");
    }
    $sv->close();

    // INSERT — tabela usa: id_ativ, descricao, tipo, data, horario, prioridade, status, id_membro, criado_em
    $stmt = $conn->prepare("
        INSERT INTO atividades (descricao, tipo, data, horario, prioridade, status, id_membro)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$stmt) throw new Exception("Prepare falhou: " . $conn->error);
    $stmt->bind_param("ssssssi", $descricao, $tipo, $data, $horario, $prioridade, $status, $id_membro);
    if (!$stmt->execute()) throw new Exception("Execute falhou: " . $stmt->error);
    $stmt->close();

    // Notificação
    $msg = "Nova atividade cadastrada: {$descricao}";
    $sn = $conn->prepare("INSERT INTO notificacoes (mensagem, id_usuario) VALUES (?, ?)");
    if ($sn) {
        $sn->bind_param("si", $msg, $id_usuario);
        $sn->execute();
        $sn->close();
    }

    setMensagem('sucesso', "Atividade cadastrada com sucesso!");

} catch (Exception $e) {
    logErro("Erro ao salvar atividade: " . $e->getMessage());
    setMensagem('erro', "Erro ao salvar atividade. Tente novamente.");
}

header("Location: ../atividades.php");
exit;

<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/verifica_login.php";
require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

try {
    $stmt = $conn->prepare("UPDATE notificacoes SET lida = 1 WHERE id_usuario = ? AND lida = 0");
    if (!$stmt) throw new Exception($conn->error);
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $count = $stmt->affected_rows;
    $stmt->close();
    if ($count > 0) {
        setMensagem('sucesso', "{$count} notificação(ões) marcada(s) como lida(s).");
    } else {
        setMensagem('info', "Nenhuma notificação não lida.");
    }
} catch (Exception $e) {
    logErro("Erro marcar todas: " . $e->getMessage());
    setMensagem('erro', "Erro ao processar.");
}

header("Location: ../notificacoes.php");
exit;

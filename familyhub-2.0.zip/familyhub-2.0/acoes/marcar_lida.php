<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/verifica_login.php";
require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

$id_not     = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$id_usuario = (int)$_SESSION['usuario_id'];

if (!$id_not || $id_not <= 0) {
    setMensagem('erro', "Notificação inválida.");
    header("Location: ../notificacoes.php");
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE notificacoes SET lida = 1 WHERE id_notificacao = ? AND id_usuario = ?");
    if (!$stmt) throw new Exception($conn->error);
    $stmt->bind_param("ii", $id_not, $id_usuario);
    $stmt->execute();
    if ($stmt->affected_rows > 0) setMensagem('sucesso', "Notificação marcada como lida.");
    $stmt->close();
} catch (Exception $e) {
    logErro("Erro ao marcar notificação: " . $e->getMessage());
    setMensagem('erro', "Erro ao processar.");
}

header("Location: ../notificacoes.php");
exit;

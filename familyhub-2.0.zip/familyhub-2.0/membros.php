<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$membros = [];
$stmt = $conn->prepare("SELECT * FROM membros WHERE id_usuario = ? ORDER BY criado_em DESC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $membros[] = $row;
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membros - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>👥 Membros da Família</h1>
        <p class="subtitle">Gerencie os membros da sua família</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="card">
        <div class="card-header"><h2>Cadastrar Novo Membro</h2></div>
        <form action="acoes/salvar_membro.php" method="POST" class="form-horizontal">
            <div class="form-row">
                <div class="form-group">
                    <label for="nome">Nome Completo *</label>
                    <input type="text" id="nome" name="nome" placeholder="Ex: João da Silva" required maxlength="100">
                </div>
                <div class="form-group">
                    <label for="papel">Papel *</label>
                    <select id="papel" name="papel" required>
                        <option value="">Selecione...</option>
                        <option value="Pai">Pai</option>
                        <option value="Mãe">Mãe</option>
                        <option value="Filho(a)">Filho(a)</option>
                        <option value="Avô/Avó">Avô/Avó</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="data_nascimento">Data de Nascimento *</label>
                    <input type="date" id="data_nascimento" name="data_nascimento" required max="<?= date('Y-m-d') ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">➕ Adicionar Membro</button>
        </form>
    </div>

    <div class="card">
        <div class="card-header"><h2>Lista de Membros (<?= count($membros) ?>)</h2></div>

        <?php if (empty($membros)): ?>
            <div class="empty-state">
                <p>👥 Nenhum membro cadastrado ainda.</p>
                <p class="text-muted">Adicione membros da sua família acima.</p>
            </div>
        <?php else: ?>
            <div class="membros-grid">
                <?php foreach ($membros as $m):
                    $idade = '';
                    if (!empty($m['data_nascimento'])) {
                        $nasc = new DateTime($m['data_nascimento']);
                        $idade = $nasc->diff(new DateTime())->y . ' anos';
                    }
                ?>
                    <div class="membro-card">
                        <div class="membro-avatar"><?= mb_substr(esc($m['nome']), 0, 1, 'UTF-8') ?></div>
                        <div class="membro-info">
                            <h3><?= esc($m['nome']) ?></h3>
                            <p class="membro-papel"><?= esc($m['papel']) ?></p>
                            <?php if ($idade): ?><p class="membro-idade">🎂 <?= $idade ?></p><?php endif; ?>
                            <p class="text-muted">Cadastrado em <?= formatarData(date('Y-m-d', strtotime($m['criado_em']))) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

-- Cria o banco de dados
create DATABASE familyhub

-- Abrir a tabela familyhub
USE familyhub;

-- Cria tabela de usuarios 
create table usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- cria a tabela dos membros da família
create table membros (
    id_membro INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    papel VARCHAR(50) NOT NULL,
    data_nascimento DATE,
    id_usuario INT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_membro_usuario
    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
);

-- Cria a tabela de atividades
create table atividades (
    id_ativ INT AUTO_INCREMENT PRIMARY KEY,
    descricao TEXT NOT NULL,
    tipo ENUM('Escolar', 'Esporte', 'Social', 'Casa', 'Saude' , 'Outro' ) NOT NULL,
    data DATE NOT NULL,
    horario TIME NOT NULL,
    prioridade ENUM('Baixa', 'Média', 'Alta') DEFAULT 'Média',
    status ENUM('Pendente', 'Processo', 'Concluída') DEFAULT 'Pendente',
    id_membro INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_atividade_membro
    FOREIGN KEY (id_membro)
    REFERENCES membros(id_membro)
    ON DELETE CASCADE
);

-- Criar tabela de notificação
create table notificacoes (
    id_notificacao INT AUTO_INCREMENT PRIMARY KEY,
    mensagem TEXT NOT NULL,
    lida BOOLEAN DEFAULT FALSE,
    id_usuario INT NOT NULL,
    criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
);
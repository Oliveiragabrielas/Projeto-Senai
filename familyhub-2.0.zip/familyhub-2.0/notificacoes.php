<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$notificacoes = [];
$stmt = $conn->prepare("SELECT * FROM notificacoes WHERE id_usuario = ? ORDER BY criada_em DESC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $notificacoes[] = $row;
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificações - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<div class="content">
    <div class="page-header">
        <h1>🔔 Notificações</h1>
        <p class="subtitle">Seus avisos e alertas</p>
    </div>

    <?= exibirAlertas() ?>

    <?php if (!empty($notificacoes)): ?>
        <div style="text-align:right; margin-bottom:1rem;">
            <a href="acoes/marcar_todas_lidas.php" class="btn btn-sm">✔ Marcar todas como lidas</a>
        </div>
    <?php endif; ?>

    <div class="card">
        <?php if (empty($notificacoes)): ?>
            <div class="empty-state"><p>🔔 Nenhuma notificação ainda.</p></div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr><th>Mensagem</th><th>Data</th><th>Status</th><th>Ação</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($notificacoes as $n): ?>
                            <tr class="<?= !$n['lida'] ? 'row-nao-lida' : '' ?>">
                                <td><?= esc($n['mensagem']) ?></td>
                                <td><?= formatarData(date('Y-m-d', strtotime($n['criada_em']))) ?></td>
                                <td>
                                    <?php if ($n['lida']): ?>
                                        <span class="badge badge-concluída">Lida</span>
                                    <?php else: ?>
                                        <span class="badge badge-pendente">Não lida</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!$n['lida']): ?>
                                        <a href="acoes/marcar_lida.php?id=<?= (int)$n['id_notificacao'] ?>" class="btn btn-sm">Marcar lida</a>
                                    <?php else: ?>
                                        &mdash;
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

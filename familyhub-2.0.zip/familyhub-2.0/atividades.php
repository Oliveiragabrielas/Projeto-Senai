<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$atividades = [];
$stmt = $conn->prepare("SELECT a.*, m.nome as nome_membro FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? ORDER BY a.data ASC, a.horario ASC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $atividades[] = $row;
    $stmt->close();
}

$membros = [];
$stmtM = $conn->prepare("SELECT id_membro, nome FROM membros WHERE id_usuario = ? ORDER BY nome");
if ($stmtM) {
    $stmtM->bind_param("i", $id_usuario);
    $stmtM->execute();
    $res = $stmtM->get_result();
    while ($row = $res->fetch_assoc()) $membros[] = $row;
    $stmtM->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividades - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>📋 Gestão de Atividades</h1>
        <p class="subtitle">Cadastre e acompanhe as atividades da família</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="card">
        <div class="card-header"><h2>Nova Atividade</h2></div>

        <form action="acoes/salvar_atividade.php" method="POST" class="form-horizontal">
            <div class="form-row">
                <div class="form-group">
                    <label for="descricao">Descrição *</label>
                    <input type="text" id="descricao" name="descricao" placeholder="Ex: Reunião escolar" required maxlength="200">
                </div>
                <div class="form-group">
                    <label for="data">Data *</label>
                    <input type="date" id="data" name="data" required>
                </div>
                <div class="form-group">
                    <label for="horario">Horário *</label>
                    <input type="time" id="horario" name="horario" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="tipo">Tipo *</label>
                    <select id="tipo" name="tipo" required>
                        <option value="">Selecione...</option>
                        <!-- Valores EXATOS do ENUM no banco -->
                        <option value="Escolar">Escolar</option>
                        <option value="Esporte">Esporte</option>
                        <option value="Social">Social</option>
                        <option value="Casa">Casa</option>
                        <option value="Saude">Saúde</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="prioridade">Prioridade</label>
                    <select id="prioridade" name="prioridade">
                        <option value="Baixa">Baixa</option>
                        <option value="Média" selected>Média</option>
                        <option value="Alta">Alta</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="Pendente">Pendente</option>
                        <option value="Processo">Em Processo</option>
                        <option value="Concluída">Concluída</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_membro">Membro *</label>
                    <select id="id_membro" name="id_membro" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($membros as $m): ?>
                            <option value="<?= (int)$m['id_membro'] ?>"><?= esc($m['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($membros)): ?>
                        <small class="form-hint">Nenhum membro. <a href="membros.php">Cadastre um membro</a> primeiro.</small>
                    <?php endif; ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" <?= empty($membros) ? 'disabled' : '' ?>>
                ➕ Cadastrar Atividade
            </button>
        </form>
    </div>

    <div class="card">
        <div class="card-header">
            <h2>Lista de Atividades (<?= count($atividades) ?>)</h2>
        </div>

        <?php if (empty($atividades)): ?>
            <div class="empty-state"><p>📋 Nenhuma atividade cadastrada ainda.</p></div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Data</th><th>Horário</th><th>Descrição</th>
                            <th>Tipo</th><th>Membro</th><th>Prioridade</th><th>Status</th><th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($atividades as $a): ?>
                            <tr>
                                <td><?= formatarData($a['data']) ?></td>
                                <td><?= date('H:i', strtotime($a['horario'])) ?></td>
                                <td><?= esc($a['descricao']) ?></td>
                                <td><?= esc($a['tipo']) ?></td>
                                <td><?= esc($a['nome_membro']) ?></td>
                                <td><?= esc($a['prioridade']) ?></td>
                                <td><span class="badge badge-<?= strtolower(esc($a['status'])) ?>"><?= esc($a['status']) ?></span></td>
                                <td>
                                    <!-- id_ativ é o nome da PK no banco -->
                                    <a href="acoes/excluir_atividade.php?id=<?= (int)$a['id_ativ'] ?>"
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Deseja excluir esta atividade?')">Excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</main>
</body>
</html>

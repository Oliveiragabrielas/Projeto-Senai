<?php
// Configurar sessão ANTES de session_start()
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];
$pendentes  = 0;
$processo   = 0;
$concluidas = 0;

$stmtPend = $conn->prepare("SELECT COUNT(*) as total FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? AND a.status = 'Pendente'");
if ($stmtPend) { $stmtPend->bind_param("i", $id_usuario); $stmtPend->execute(); $pendentes = (int)$stmtPend->get_result()->fetch_assoc()['total']; $stmtPend->close(); }

$stmtProc = $conn->prepare("SELECT COUNT(*) as total FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? AND a.status = 'Processo'");
if ($stmtProc) { $stmtProc->bind_param("i", $id_usuario); $stmtProc->execute(); $processo = (int)$stmtProc->get_result()->fetch_assoc()['total']; $stmtProc->close(); }

$stmtConc = $conn->prepare("SELECT COUNT(*) as total FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? AND a.status = 'Concluída'");
if ($stmtConc) { $stmtConc->bind_param("i", $id_usuario); $stmtConc->execute(); $concluidas = (int)$stmtConc->get_result()->fetch_assoc()['total']; $stmtConc->close(); }

$atividadesRecentes = [];
$stmtR = $conn->prepare("SELECT a.*, m.nome as nome_membro FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? ORDER BY a.data DESC, a.horario DESC LIMIT 5");
if ($stmtR) {
    $stmtR->bind_param("i", $id_usuario);
    $stmtR->execute();
    $res = $stmtR->get_result();
    while ($row = $res->fetch_assoc()) $atividadesRecentes[] = $row;
    $stmtR->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<div class="content">
    <div class="page-header">
        <h1>Bem-vindo, <?= esc($_SESSION['usuario_nome']) ?>! 👋</h1>
        <p class="subtitle">Aqui está um resumo das suas atividades familiares</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="cards-grid">
        <div class="stat-card pendente">
            <div class="stat-icon">⏳</div>
            <div class="stat-info"><h3>Pendentes</h3><p class="stat-number"><?= $pendentes ?></p></div>
        </div>
        <div class="stat-card processo">
            <div class="stat-icon">🔄</div>
            <div class="stat-info"><h3>Em Processo</h3><p class="stat-number"><?= $processo ?></p></div>
        </div>
        <div class="stat-card concluida">
            <div class="stat-icon">✅</div>
            <div class="stat-info"><h3>Concluídas</h3><p class="stat-number"><?= $concluidas ?></p></div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h2>Atividades Recentes</h2>
            <a href="atividades.php" class="btn btn-sm">Ver Todas</a>
        </div>

        <?php if (empty($atividadesRecentes)): ?>
            <div class="empty-state">
                <p>📋 Nenhuma atividade cadastrada ainda.</p>
                <a href="atividades.php" class="btn btn-primary">Cadastrar Atividade</a>
            </div>
        <?php else: ?>
            <div class="atividades-list">
                <?php foreach ($atividadesRecentes as $ativ): ?>
                    <div class="atividade-item">
                        <div class="atividade-info">
                            <span class="badge badge-<?= strtolower(esc($ativ['status'])) ?>"><?= esc($ativ['status']) ?></span>
                            <span class="atividade-tipo"><?= esc($ativ['tipo']) ?></span>
                            <h4><?= esc($ativ['descricao']) ?></h4>
                            <p class="atividade-meta">
                                👤 <?= esc($ativ['nome_membro']) ?> &bull;
                                📅 <?= formatarData($ativ['data']) ?> &bull;
                                🕐 <?= date('H:i', strtotime($ativ['horario'])) ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>

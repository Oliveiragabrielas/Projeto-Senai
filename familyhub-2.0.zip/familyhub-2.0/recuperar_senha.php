<?php
session_start();
require_once "includes/funcoes.php";

// Redirecionar se já estiver logado
if (usuarioLogado()) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="login-body">

<div class="login-container">
    <div class="login-box">
        <div class="login-header">
            <h1>FamilyHub</h1>
            <p>Recuperação de Senha</p>
        </div>

        <div class="alert alert-info">
            <strong>Em desenvolvimento</strong><br>
            Esta funcionalidade estará disponível em breve. Por enquanto, entre em contato com o administrador para recuperar sua senha.
        </div>

        <form action="#" method="POST" class="login-form">
            <div class="form-group">
                <label for="email">Email cadastrado</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="seu@email.com"
                    disabled
                    maxlength="150"
                >
                <small class="form-hint">Enviaremos um link de recuperação</small>
            </div>

            <button type="submit" class="btn btn-primary btn-block" disabled>
                Enviar Link de Recuperação
            </button>
        </form>

        <div class="login-footer">
            <p><a href="login.php">&larr; Voltar para o login</a></p>
        </div>
    </div>
</div>

</body>
</html>
<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$atividades = [];
$stmt = $conn->prepare("SELECT a.*, m.nome as nome_membro FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? ORDER BY a.data ASC, a.horario ASC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $atividades[] = $row;
    $stmt->close();
}

// Agrupar por mês
$porMes = [];
foreach ($atividades as $a) {
    $mes = date('Y-m', strtotime($a['data']));
    $porMes[$mes][] = $a;
}

$meses_pt = ['01'=>'Janeiro','02'=>'Fevereiro','03'=>'Março','04'=>'Abril','05'=>'Maio','06'=>'Junho','07'=>'Julho','08'=>'Agosto','09'=>'Setembro','10'=>'Outubro','11'=>'Novembro','12'=>'Dezembro'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>📅 Calendário de Atividades</h1>
        <p class="subtitle">Atividades organizadas por data</p>
    </div>

    <?= exibirAlertas() ?>

    <?php if (empty($atividades)): ?>
        <div class="card">
            <div class="empty-state">
                <p>📅 Nenhuma atividade cadastrada ainda.</p>
                <a href="atividades.php" class="btn btn-primary">Cadastrar Atividade</a>
            </div>
        </div>
    <?php else: ?>
        <?php foreach ($porMes as $mes => $itens):
            $ano = substr($mes, 0, 4);
            $num_mes = substr($mes, 5, 2);
            $nome_mes = ($meses_pt[$num_mes] ?? $mes) . ' de ' . $ano;
        ?>
            <div class="card">
                <div class="card-header">
                    <h2>📅 <?= $nome_mes ?> <small>(<?= count($itens) ?> atividade<?= count($itens) > 1 ? 's' : '' ?>)</small></h2>
                </div>
                <ul class="calendario-list">
                    <?php foreach ($itens as $a): ?>
                        <li class="calendario-item">
                            <div class="calendario-data">
                                <span class="dia"><?= date('d', strtotime($a['data'])) ?></span>
                                <span class="hora"><?= date('H:i', strtotime($a['horario'])) ?></span>
                            </div>
                            <div class="calendario-info">
                                <strong><?= esc($a['descricao']) ?></strong>
                                <span class="text-muted"><?= esc($a['tipo']) ?> &bull; <?= esc($a['nome_membro']) ?></span>
                            </div>
                            <span class="badge badge-<?= strtolower(esc($a['status'])) ?>"><?= esc($a['status']) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</main>
</body>
</html>

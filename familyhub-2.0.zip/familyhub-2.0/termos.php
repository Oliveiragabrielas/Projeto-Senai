<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termos de Uso - FamilyHub</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .termos-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .termos-container h1 {
            color: var(--primary);
            margin-bottom: 1rem;
        }
        .termos-container h2 {
            color: var(--gray-700);
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }
        .termos-container p {
            margin-bottom: 1rem;
            line-height: 1.8;
            color: var(--gray-700);
        }
        .termos-container ul {
            margin-left: 2rem;
            margin-bottom: 1rem;
        }
        .termos-container li {
            margin-bottom: 0.5rem;
            line-height: 1.6;
        }
    </style>
</head>
<body style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">

<div class="termos-container">
    <h1>Termos de Uso</h1>
    <p><strong>Última atualização:</strong> <?= date('d/m/Y') ?></p>

    <h2>1. Aceitação dos Termos</h2>
    <p>
        Ao acessar e usar o FamilyHub, você concorda em cumprir e estar vinculado aos seguintes termos e condições de uso.
    </p>

    <h2>2. Descrição do Serviço</h2>
    <p>O FamilyHub é uma plataforma de organização familiar que permite:</p>
    <ul>
        <li>Gerenciar membros da família</li>
        <li>Organizar atividades e eventos</li>
        <li>Receber notificações</li>
        <li>Acompanhar tarefas familiares</li>
    </ul>

    <h2>3. Cadastro e Conta</h2>
    <p>Para usar o serviço, você deve:</p>
    <ul>
        <li>Fornecer informações verdadeiras e completas</li>
        <li>Manter a confidencialidade de sua senha</li>
        <li>Ser responsável por todas as atividades em sua conta</li>
        <li>Notificar imediatamente sobre uso não autorizado</li>
    </ul>

    <h2>4. Uso Aceitável</h2>
    <p>Você concorda em NÃO:</p>
    <ul>
        <li>Usar o serviço para fins ilegais</li>
        <li>Tentar acessar contas de outros usuários</li>
        <li>Transmitir vírus ou código malicioso</li>
        <li>Coletar dados de outros usuários</li>
        <li>Usar o serviço de forma que prejudique sua funcionalidade</li>
    </ul>

    <h2>5. Privacidade</h2>
    <p>
        Seu uso do FamilyHub também é regido pela nossa <a href="privacidade.php">Política de Privacidade</a>.
    </p>

    <h2>6. Propriedade Intelectual</h2>
    <p>
        Todo o conteúdo, recursos e funcionalidades do FamilyHub são propriedade exclusiva e estão protegidos por leis de direitos autorais.
    </p>

    <h2>7. Limitação de Responsabilidade</h2>
    <p>
        O FamilyHub é fornecido "como está". Não garantimos que o serviço será ininterrupto ou livre de erros.
    </p>

    <h2>8. Modificações</h2>
    <p>
        Reservamos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor imediatamente após a publicação.
    </p>

    <h2>9. Contato</h2>
    <p>
        Para questões sobre estes termos, entre em contato:
        <a href="mailto:contato@familyhub.com">contato@familyhub.com</a>
    </p>

    <div style="margin-top: 2rem; text-align: center;">
        <a href="registro.php" class="btn btn-primary">Voltar ao Cadastro</a>
        <a href="login.php" class="btn btn-secondary">Ir para Login</a>
    </div>
</div>

</body>
</html>
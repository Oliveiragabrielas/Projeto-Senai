<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidade - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <script>
    /* Aplica tema salvo antes de renderizar – evita flash */
    (function(){
        var t = localStorage.getItem("fh-theme");
        var dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        document.documentElement.setAttribute("data-theme", t || (dark ? "dark" : "light"));
    })();
    </script>
</head>
<body class="login-body" style="align-items:flex-start; padding: 40px 20px;">

<div class="termos-doc">

    <div class="termos-doc-header">
        <a href="registro.php" class="termos-back">← Voltar</a>
        <h1>🔒 Política de Privacidade</h1>
        <p class="termos-meta">Última atualização: <?= date('d/m/Y') ?></p>
    </div>

    <section>
        <h2>1. Introdução</h2>
        <p>Esta Política de Privacidade descreve como o FamilyHub+ coleta, usa e protege suas informações pessoais.</p>
    </section>

    <section>
        <h2>2. Informações que Coletamos</h2>
        <p>Coletamos as seguintes informações quando você se cadastra:</p>
        <ul>
            <li><strong>Informações de Conta:</strong> Nome, email, telefone (opcional), senha (criptografada)</li>
            <li><strong>Informações da Família:</strong> Nomes e papéis dos membros da família</li>
            <li><strong>Atividades:</strong> Descrições, datas e horários de atividades</li>
            <li><strong>Dados de Uso:</strong> Como você interage com o serviço</li>
        </ul>
    </section>

    <section>
        <h2>3. Como Usamos Suas Informações</h2>
        <p>Usamos suas informações para:</p>
        <ul>
            <li>Fornecer e manter o serviço</li>
            <li>Processar suas solicitações</li>
            <li>Enviar notificações importantes</li>
            <li>Melhorar nosso serviço</li>
            <li>Garantir a segurança da plataforma</li>
        </ul>
    </section>

    <section>
        <h2>4. Compartilhamento de Informações</h2>
        <p><strong>Nós NÃO vendemos seus dados.</strong> Suas informações permanecem privadas e não são compartilhadas com terceiros, exceto quando:</p>
        <ul>
            <li>Exigido por lei</li>
            <li>Necessário para proteger nossos direitos</li>
            <li>Com seu consentimento explícito</li>
        </ul>
    </section>

    <section>
        <h2>5. Segurança de Dados</h2>
        <p>Implementamos medidas de segurança para proteger suas informações:</p>
        <ul>
            <li>Senhas criptografadas com bcrypt</li>
            <li>Conexões seguras (HTTPS recomendado)</li>
            <li>Proteção contra SQL Injection e XSS</li>
            <li>Sessões seguras com cookies httponly</li>
            <li>Validação de dados em todas as entradas</li>
        </ul>
    </section>

    <section>
        <h2>6. Seus Direitos</h2>
        <p>Você tem direito a:</p>
        <ul>
            <li>Acessar seus dados pessoais</li>
            <li>Corrigir informações incorretas</li>
            <li>Excluir sua conta e dados</li>
            <li>Exportar seus dados</li>
            <li>Optar por não receber comunicações</li>
        </ul>
    </section>

    <section>
        <h2>7. Retenção de Dados</h2>
        <p>Mantemos suas informações enquanto sua conta estiver ativa. Após a exclusão da conta, seus dados são removidos permanentemente em até 30 dias.</p>
    </section>

    <section>
        <h2>8. Cookies</h2>
        <p>Usamos cookies apenas para manter sua sessão ativa e melhorar sua experiência. Não usamos cookies de rastreamento de terceiros.</p>
    </section>

    <section>
        <h2>9. Crianças</h2>
        <p>O FamilyHub+ pode armazenar informações sobre membros da família menores de idade, mas apenas o responsável legal pode criar e gerenciar a conta.</p>
    </section>

    <section>
        <h2>10. Alterações nesta Política</h2>
        <p>Podemos atualizar esta política ocasionalmente. Notificaremos você sobre alterações significativas por email ou através de aviso no serviço.</p>
    </section>

    <section>
        <h2>11. Contato</h2>
        <p>Para questões sobre privacidade, entre em contato:</p>
        <ul>
            <li><strong>Email:</strong> <a href="mailto:privacidade@familyplus.com">privacidade@familyplus.com</a></li>
            <li><strong>Telefone:</strong> (11) 0000-0000</li>
        </ul>
    </section>

    <section>
        <h2>12. Consentimento</h2>
        <p>Ao usar o FamilyHub+, você concorda com esta Política de Privacidade.</p>
    </section>

    <div class="termos-doc-footer">
        <a href="registro.php" class="btn btn-primary">Voltar ao Cadastro</a>
        <a href="login.php" class="btn btn-secondary">Ir para Login</a>
    </div>

</div>


<!-- ===== BOTÃO DE TEMA FLUTUANTE ===== -->
<button id="fh-theme-btn"
    title="Alternar modo claro/escuro"
    style="position:fixed;bottom:24px;right:24px;z-index:9999;
           width:46px;height:46px;border-radius:50%;cursor:pointer;
           background:var(--bg-card);border:1.5px solid var(--border);
           box-shadow:var(--shadow-md);font-size:1.25rem;
           display:flex;align-items:center;justify-content:center;
           transition:transform .2s,box-shadow .2s;">
    <span id="fh-ti">🌙</span>
</button>
<script>
(function(){
    var html = document.documentElement;
    var btn  = document.getElementById("fh-theme-btn");
    var icon = document.getElementById("fh-ti");
    function sync(){ icon.textContent = html.getAttribute("data-theme")==="dark" ? "☀️" : "🌙"; }
    sync();
    btn.addEventListener("click", function(){
        var next = html.getAttribute("data-theme")==="light" ? "dark" : "light";
        html.setAttribute("data-theme", next);
        localStorage.setItem("fh-theme", next);
        sync();
    });
    btn.addEventListener("mouseover", function(){ btn.style.transform = "scale(1.12)"; });
    btn.addEventListener("mouseout",  function(){ btn.style.transform = "scale(1)"; });
})();
</script>
</body>
</html>
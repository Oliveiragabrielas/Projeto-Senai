<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$notificacoes = [];
$stmt = $conn->prepare("SELECT * FROM notificacoes WHERE id_usuario = ? ORDER BY criada_em DESC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $notificacoes[] = $row;
    $stmt->close();
}

$totalNaoLidas = count(array_filter($notificacoes, fn($n) => !$n['lida']));

function detectarTipo(string $msg): array {
    if (str_starts_with($msg, '✅')) return ['tipo'=>'concluida','cor'=>'#27ae60','bg'=>'rgba(39,174,96,0.12)','borda'=>'rgba(39,174,96,0.35)'];
    if (str_starts_with($msg, '➕')) return ['tipo'=>'nova',     'cor'=>'#3b9eff','bg'=>'rgba(59,158,255,0.12)','borda'=>'rgba(59,158,255,0.35)'];
    if (str_starts_with($msg, '✏'))  return ['tipo'=>'editada',  'cor'=>'#f39c12','bg'=>'rgba(243,156,18,0.12)','borda'=>'rgba(243,156,18,0.35)'];
    if (str_starts_with($msg, '🗑'))  return ['tipo'=>'excluida', 'cor'=>'#e74c3c','bg'=>'rgba(231,76,60,0.12)', 'borda'=>'rgba(231,76,60,0.35)'];
    if (str_starts_with($msg, '👤')) return ['tipo'=>'membro',   'cor'=>'#a78bfa','bg'=>'rgba(167,139,250,0.12)','borda'=>'rgba(167,139,250,0.35)'];
    return                                  ['tipo'=>'geral',    'cor'=>'#aaa',   'bg'=>'rgba(255,255,255,0.06)','borda'=>'rgba(255,255,255,0.12)'];
}

function tempoRelativo(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)     return 'agora mesmo';
    if ($diff < 3600)   return 'há ' . floor($diff/60) . ' min';
    if ($diff < 86400)  return 'há ' . floor($diff/3600) . 'h';
    if ($diff < 604800) return 'há ' . floor($diff/86400) . ' dia' . (floor($diff/86400) > 1 ? 's' : '');
    return date('d/m/Y', strtotime($datetime));
}

function extrairInicial(string $msg): string {
    $clean = trim(preg_replace('/^\X{1,3}\s*/u', '', $msg));
    return mb_strtoupper(mb_substr($clean, 0, 1, 'UTF-8'), 'UTF-8') ?: '?';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificações - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .notif-header-stats {
            display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap; align-items: center;
        }
        .notif-stat {
            display: flex; align-items: center; gap: 10px;
            padding: 10px 18px; border-radius: var(--r-md);
            background: var(--bg-card); border: 1px solid var(--border);
        }
        .notif-stat .num { font-size: 1.4rem; font-weight: 800; line-height: 1; }
        .notif-stat .lbl { font-size: 0.72rem; color: var(--text-muted); }
        .notif-stat.nao-lidas .num { color: #f39c12; }
        .notif-stat.total .num { color: var(--accent); }

        .notif-list { display: flex; flex-direction: column; gap: 10px; }

        .notif-item {
            display: flex; align-items: flex-start; gap: 14px;
            padding: 16px 18px; border-radius: var(--r-md);
            border: 1px solid var(--border); background: var(--bg-card);
            transition: transform 0.15s; position: relative;
        }
        .notif-item:hover { transform: translateX(4px); }
        .notif-item.nao-lida { border-left-width: 3px; }
        .notif-item.nao-lida::after {
            content: ''; position: absolute; top: 14px; right: 14px;
            width: 8px; height: 8px; border-radius: 50%;
            background: #f39c12; box-shadow: 0 0 6px rgba(243,156,18,0.7);
        }

        .notif-avatar {
            width: 44px; height: 44px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.1rem; font-weight: 800; color: #fff; flex-shrink: 0;
        }
        .notif-body { flex: 1; min-width: 0; }
        .notif-msg {
            font-size: 0.92rem; color: var(--text-primary);
            line-height: 1.55; font-weight: 500; word-break: break-word;
        }
        .notif-item.lida .notif-msg { color: var(--text-secondary); font-weight: 400; }

        .notif-meta {
            display: flex; align-items: center; gap: 8px;
            margin-top: 7px; flex-wrap: wrap;
        }
        .notif-tempo { font-size: 0.75rem; color: var(--text-muted); }
        .notif-badge {
            font-size: 0.7rem; font-weight: 700;
            padding: 2px 8px; border-radius: 20px;
        }

        .notif-actions { display: flex; align-items: center; flex-shrink: 0; padding-top: 2px; }

        .notif-group-label {
            font-size: 0.73rem; font-weight: 700; color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.08em;
            padding: 12px 2px 6px; border-bottom: 1px solid var(--border);
            margin-bottom: 4px;
        }
        .notif-group-label:first-child { padding-top: 0; }

        .notif-empty {
            display: flex; flex-direction: column; align-items: center;
            padding: 60px 20px; gap: 10px; color: var(--text-muted);
        }
        .notif-empty-icon { font-size: 3rem; }
    </style>
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>🔔 Notificações</h1>
        <p class="subtitle">Histórico de ações realizadas pela sua família</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="notif-header-stats">
        <div class="notif-stat total">
            <span style="font-size:1.3rem">📋</span>
            <div><div class="num"><?= count($notificacoes) ?></div><div class="lbl">Total</div></div>
        </div>
        <div class="notif-stat nao-lidas">
            <span style="font-size:1.3rem">🔴</span>
            <div><div class="num"><?= $totalNaoLidas ?></div><div class="lbl">Não lidas</div></div>
        </div>
        <?php if ($totalNaoLidas > 0): ?>
        <div style="margin-left:auto">
            <a href="acoes/marcar_todas_lidas.php" class="btn btn-sm">✔ Marcar todas como lidas</a>
        </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <?php if (empty($notificacoes)): ?>
            <div class="notif-empty">
                <div class="notif-empty-icon">🔔</div>
                <p style="font-size:1rem;margin:0">Nenhuma notificação ainda.</p>
                <p style="font-size:0.85rem;margin:0">As ações da família aparecerão aqui.</p>
            </div>
        <?php else: ?>
            <div class="notif-list">
            <?php
            $grupoAtual = '';
            foreach ($notificacoes as $n):
                $tipo  = detectarTipo($n['mensagem']);
                $lida  = (bool)$n['lida'];

                $dataNotif  = date('Y-m-d', strtotime($n['criada_em']));
                $hoje       = date('Y-m-d');
                $ontem      = date('Y-m-d', strtotime('-1 day'));
                if ($dataNotif === $hoje)       $grupoLabel = 'Hoje';
                elseif ($dataNotif === $ontem)  $grupoLabel = 'Ontem';
                else                            $grupoLabel = date('d/m/Y', strtotime($n['criada_em']));

                if ($grupoLabel !== $grupoAtual):
                    $grupoAtual = $grupoLabel;
            ?>
                <div class="notif-group-label"><?= $grupoLabel ?></div>
            <?php endif; ?>

                <div class="notif-item <?= $lida ? 'lida' : 'nao-lida' ?>"
                     style="border-color:<?= $lida ? 'var(--border)' : $tipo['borda'] ?>;
                            background:<?= $lida ? 'var(--bg-card)' : $tipo['bg'] ?>;
                            <?= !$lida ? 'border-left-color:'.$tipo['cor'].';' : '' ?>">

                    <div class="notif-avatar"
                         style="background:linear-gradient(135deg,<?= $tipo['cor'] ?>99,<?= $tipo['cor'] ?>44)">
                        <?= extrairInicial($n['mensagem']) ?>
                    </div>

                    <div class="notif-body">
                        <div class="notif-msg"><?= esc($n['mensagem']) ?></div>
                        <div class="notif-meta">
                            <span class="notif-tempo">🕐 <?= tempoRelativo($n['criada_em']) ?></span>
                            <span class="notif-badge"
                                  style="background:<?= $tipo['bg'] ?>;color:<?= $tipo['cor'] ?>;border:1px solid <?= $tipo['borda'] ?>">
                                <?= match($tipo['tipo']) {
                                    'concluida' => '✅ Concluída',
                                    'nova'      => '➕ Nova atividade',
                                    'editada'   => '✏️ Editada',
                                    'excluida'  => '🗑️ Excluída',
                                    'membro'    => '👤 Membro',
                                    default     => '📌 Geral'
                                } ?>
                            </span>
                            <?php if ($lida): ?>
                                <span style="font-size:0.7rem;color:var(--text-muted)">✔ lida em <?= date('d/m H:i', strtotime($n['criada_em'])) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!$lida): ?>
                    <div class="notif-actions">
                        <a href="acoes/marcar_lida.php?id=<?= (int)$n['id_notificacao'] ?>"
                           class="btn btn-sm btn-secondary" title="Marcar como lida" style="padding:5px 10px;font-size:0.8rem">✔</a>
                    </div>
                    <?php endif; ?>
                </div>

            <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</main>

</body>
</html>

<?php
/**
 * Verificação de Login - FamilyHub+
 */

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once __DIR__ . '/funcoes.php';

// 1. Precisa estar logado
if (!usuarioLogado()) {
    header("Location: login.php");
    exit;
}

// 2. Precisa ter escolhido um perfil/membro
$paginaAtual  = basename($_SERVER['PHP_SELF']);
$paginasLivres = ['escolher_membro.php', 'logout.php'];

if (!in_array($paginaAtual, $paginasLivres) && !array_key_exists('membro_id', $_SESSION)) {
    header("Location: escolher_membro.php");
    exit;
}

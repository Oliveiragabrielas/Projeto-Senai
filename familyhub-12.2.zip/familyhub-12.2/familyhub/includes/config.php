<?php
/**
 * Configuração - FamilyHub+
 */

// Configurações de erro (mude DEBUG_MODE para false em produção)
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// ─── Banco de Dados ────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_USER',    'root');        // ← seu usuário MySQL
define('DB_PASS',    'Senai@118');            // ← sua senha MySQL
define('DB_NAME',    'familyhub');
define('DB_CHARSET', 'utf8mb4');

// ─── Sistema ───────────────────────────────────────────────────
define('SITE_NAME',        'FamilyHub+');
define('TIMEZONE',         'America/Sao_Paulo');
define('SESSION_LIFETIME', 7200);
define('SESSION_NAME',     'FAMILYHUB_SESSION');

date_default_timezone_set(TIMEZONE);

// Configurar sessão apenas se ainda não foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    session_name(SESSION_NAME);
}

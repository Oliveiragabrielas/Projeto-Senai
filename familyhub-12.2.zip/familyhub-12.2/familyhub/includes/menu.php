<?php
/**
 * Menu lateral - FamilyHub+
 */

$totalNotif = 0;

if (isset($_SESSION['usuario_id'], $conn)) {
    $uid = (int)$_SESSION['usuario_id'];
    $q = $conn->prepare("SELECT COUNT(*) as total FROM notificacoes WHERE id_usuario = ? AND lida = 0");
    if ($q) {
        $q->bind_param("i", $uid);
        $q->execute();
        $totalNotif = (int)$q->get_result()->fetch_assoc()['total'];
        $q->close();
    }
}

$pg = basename($_SERVER['PHP_SELF']);

// Membro ativo na sessão
$membroNome  = $_SESSION['membro_nome']  ?? ($_SESSION['usuario_nome'] ?? 'Usuário');
$membroPapel = $_SESSION['membro_papel'] ?? 'Família';
$membroInicial = mb_strtoupper(mb_substr(trim($membroNome), 0, 1, 'UTF-8'), 'UTF-8');
?>
<script src="js/app.js" defer></script>
<div class="sidebar">
    <h2>FamilyHub+</h2>

    <!-- Card do perfil ativo -->
    <div class="user-card" title="<?= esc($membroNome) ?>">
        <div class="user-card-avatar"><?= $membroInicial ?></div>
        <div class="user-card-info">
            <span class="user-card-name"><?= esc($membroNome) ?></span>
            <span class="user-card-status">
                <span class="status-dot"></span> <?= esc($membroPapel) ?>
            </span>
        </div>
    </div>

    <!-- Botão trocar perfil -->
    <a href="escolher_membro.php" class="btn-trocar-perfil" title="Trocar de perfil">
        🔄 Trocar perfil
    </a>

    <nav>
        <a href="index.php"       class="<?= $pg === 'index.php'       ? 'active' : '' ?>"><span class="icon">📊</span> <span class="nav-label">Dashboard</span></a>
        <a href="atividades.php"  class="<?= $pg === 'atividades.php'  ? 'active' : '' ?>"><span class="icon">📋</span> <span class="nav-label">Atividades</span></a>
        <a href="calendario.php"  class="<?= $pg === 'calendario.php'  ? 'active' : '' ?>"><span class="icon">📅</span> <span class="nav-label">Calendário</span></a>
        <a href="ranking.php"    class="<?= $pg === 'ranking.php'    ? 'active' : '' ?>"><span class="icon">🏆</span> <span class="nav-label">Ranking</span></a>
        <a href="notificacoes.php" class="<?= $pg === 'notificacoes.php' ? 'active' : '' ?>">
            <span class="icon">🔔</span> <span class="nav-label">Notificações</span>
            <?php if ($totalNotif > 0): ?>
                <span class="badge"><?= $totalNotif ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php" class="logout"><span class="icon">🚪</span> <span class="nav-label">Sair</span></a>
    </nav>

    <!-- Botão Modo Claro/Escuro -->
    <button class="theme-toggle" id="theme-toggle" type="button" title="Alternar tema" aria-label="Alternar entre modo claro e escuro">
        <span class="theme-toggle-label">
            <span class="icon" id="theme-icon">🌙</span>
            <span id="theme-label">Modo Claro</span>
        </span>
        <span class="theme-switch" id="theme-switch"></span>
    </button>
</div>

<script>
(function () {
    const html    = document.documentElement;
    const btn     = document.getElementById('theme-toggle');
    const icon    = document.getElementById('theme-icon');
    const label   = document.getElementById('theme-label');

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme);
        if (theme === 'light') {
            icon.textContent  = '☀️';
            label.textContent = 'Modo Escuro';
        } else {
            icon.textContent  = '🌙';
            label.textContent = 'Modo Claro';
        }
        localStorage.setItem('fh-theme', theme);
    }

    const saved = localStorage.getItem('fh-theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    applyTheme(saved || (prefersDark ? 'dark' : 'light'));

    btn.addEventListener('click', function () {
        const current = html.getAttribute('data-theme');
        applyTheme(current === 'light' ? 'dark' : 'light');
    });
})();
</script>

/**
 * FamilyHub — app.js
 * Funções JavaScript para toda a aplicação
 */

// ============================================================
// 1. UTILITÁRIOS GERAIS
// ============================================================

/**
 * Formata uma data ISO (YYYY-MM-DD) para o padrão brasileiro (DD/MM/YYYY).
 * @param {string} isoDate
 * @returns {string}
 */
function formatarDataBR(isoDate) {
  if (!isoDate) return '—';
  const [ano, mes, dia] = isoDate.split('-');
  return `${dia}/${mes}/${ano}`;
}

/**
 * Calcula a idade em anos a partir de uma data de nascimento (YYYY-MM-DD).
 * @param {string} dataNasc
 * @returns {number}
 */
function calcularIdade(dataNasc) {
  const nasc = new Date(dataNasc);
  const hoje = new Date();
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const aniversarioPassou =
    hoje.getMonth() > nasc.getMonth() ||
    (hoje.getMonth() === nasc.getMonth() && hoje.getDate() >= nasc.getDate());
  if (!aniversarioPassou) idade--;
  return idade;
}

/**
 * Mostra um toast (mensagem flutuante) na tela.
 * @param {string} mensagem
 * @param {'sucesso'|'erro'|'aviso'|'info'} tipo
 * @param {number} duracao - ms antes de sumir (padrão 3500)
 */
function mostrarToast(mensagem, tipo = 'info', duracao = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const cores = {
    sucesso: '#a78bfa',
    erro:    '#e74c3c',
    aviso:   '#f39c12',
    info:    '#3498db',
  };
  const icones = { sucesso: '✅', erro: '❌', aviso: '⚠️', info: 'ℹ️' };

  const toast = document.createElement('div');
  toast.className = 'fh-toast';
  toast.innerHTML = `<span>${icones[tipo] ?? 'ℹ️'}</span> ${mensagem}`;
  toast.style.cssText = `
    background: ${cores[tipo] ?? cores.info};
    color: #fff;
    padding: 12px 20px;
    border-radius: 8px;
    margin-top: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    font-size: 0.95rem;
    opacity: 0;
    transform: translateX(60px);
    transition: opacity 0.3s, transform 0.3s;
    max-width: 340px;
    cursor: pointer;
  `;

  container.appendChild(toast);

  // Anima entrada
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  const remover = () => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(60px)';
    setTimeout(() => toast.remove(), 350);
  };

  toast.addEventListener('click', remover);
  setTimeout(remover, duracao);
}

// Estilos base do container de toast (injetados uma vez)
(function injetarEstilosToast() {
  if (document.getElementById('fh-toast-style')) return;
  const style = document.createElement('style');
  style.id = 'fh-toast-style';
  style.textContent = `
    #toast-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
  `;
  document.head.appendChild(style);
})();


// ============================================================
// 2. FORMULÁRIOS — VALIDAÇÃO E UX
// ============================================================

/**
 * Valida o formulário de nova atividade antes de enviar.
 * Retorna true se válido, false (e exibe toast) se inválido.
 * @param {HTMLFormElement} form
 * @returns {boolean}
 */
function validarFormularioAtividade(form) {
  const descricao = form.querySelector('[name="descricao"]');
  const data      = form.querySelector('[name="data"]');
  const horario   = form.querySelector('[name="horario"]');
  const membro    = form.querySelector('[name="id_membro"]');
  const tipo      = form.querySelector('[name="tipo"]');

  if (!descricao?.value.trim()) {
    mostrarToast('Informe a descrição da atividade.', 'aviso');
    descricao?.focus();
    return false;
  }
  if (!data?.value) {
    mostrarToast('Informe a data da atividade.', 'aviso');
    data?.focus();
    return false;
  }
  if (!horario?.value) {
    mostrarToast('Informe o horário da atividade.', 'aviso');
    horario?.focus();
    return false;
  }
  if (!tipo?.value) {
    mostrarToast('Selecione o tipo de atividade.', 'aviso');
    tipo?.focus();
    return false;
  }
  if (!membro?.value) {
    mostrarToast('Selecione o membro responsável.', 'aviso');
    membro?.focus();
    return false;
  }
  return true;
}

/**
 * Valida o formulário de cadastro de membro.
 * @param {HTMLFormElement} form
 * @returns {boolean}
 */
function validarFormularioMembro(form) {
  const nome     = form.querySelector('[name="nome"]');
  const papel    = form.querySelector('[name="papel"]');
  const dataNasc = form.querySelector('[name="data_nascimento"]');

  if (!nome?.value.trim()) {
    mostrarToast('Informe o nome do membro.', 'aviso');
    nome?.focus();
    return false;
  }
  if (!papel?.value) {
    mostrarToast('Selecione o papel do membro.', 'aviso');
    papel?.focus();
    return false;
  }
  if (!dataNasc?.value) {
    mostrarToast('Informe a data de nascimento.', 'aviso');
    dataNasc?.focus();
    return false;
  }

  const idade = calcularIdade(dataNasc.value);
  if (idade < 0 || idade > 130) {
    mostrarToast('Data de nascimento inválida.', 'erro');
    dataNasc?.focus();
    return false;
  }

  return true;
}

/**
 * Define a data mínima dos inputs de data para hoje (útil para novas atividades).
 * @param {string} seletorInput - seletor CSS do input de data
 * @param {boolean} futura - true = apenas datas futuras; false = qualquer data
 */
function configurarInputData(seletorInput, futura = false) {
  const inputs = document.querySelectorAll(seletorInput);
  const hoje = new Date().toISOString().split('T')[0];
  inputs.forEach(input => {
    if (futura) input.min = hoje;
    else input.max = hoje;
  });
}


// ============================================================
// 3. FILTRO / BUSCA DE ATIVIDADES (lado cliente)
// ============================================================

/**
 * Filtra as linhas da tabela de atividades com base em texto digitado.
 * @param {string} seletorInput  - input de busca
 * @param {string} seletorTabela - tabela com as atividades
 */
function iniciarBuscaAtividades(seletorInput = '#busca-atividade', seletorTabela = '.table tbody') {
  const input  = document.querySelector(seletorInput);
  const tbody  = document.querySelector(seletorTabela);
  if (!input || !tbody) return;

  input.addEventListener('input', () => {
    const termo = input.value.toLowerCase().trim();
    const linhas = tbody.querySelectorAll('tr');

    let visiveis = 0;
    linhas.forEach(tr => {
      const texto = tr.textContent.toLowerCase();
      const mostrar = !termo || texto.includes(termo);
      tr.style.display = mostrar ? '' : 'none';
      if (mostrar) visiveis++;
    });

    // Exibe mensagem de "nenhum resultado"
    let semResultado = tbody.querySelector('.sem-resultado');
    if (visiveis === 0) {
      if (!semResultado) {
        semResultado = document.createElement('tr');
        semResultado.className = 'sem-resultado';
        semResultado.innerHTML = `<td colspan="8" style="text-align:center;padding:20px;opacity:.7">🔍 Nenhuma atividade encontrada para "<em>${escapeHTML(termo)}</em>"</td>`;
        tbody.appendChild(semResultado);
      }
    } else {
      semResultado?.remove();
    }
  });
}

/**
 * Filtra atividades pelo status selecionado (botões ou select).
 * @param {string} seletorFiltros  - botões/selects com data-status
 * @param {string} seletorTabela
 */
function iniciarFiltroStatus(seletorFiltros = '[data-status]', seletorTabela = '.table tbody') {
  const filtros = document.querySelectorAll(seletorFiltros);
  const tbody   = document.querySelector(seletorTabela);
  if (!filtros.length || !tbody) return;

  filtros.forEach(btn => {
    btn.addEventListener('click', () => {
      filtros.forEach(b => b.classList.remove('ativo'));
      btn.classList.add('ativo');

      const status = btn.dataset.status?.toLowerCase() ?? '';
      tbody.querySelectorAll('tr').forEach(tr => {
        const badge = tr.querySelector('.badge');
        const textoStatus = badge?.textContent.toLowerCase() ?? '';
        tr.style.display = (!status || textoStatus === status) ? '' : 'none';
      });
    });
  });
}

/**
 * Escapa HTML para evitar XSS em textos dinâmicos.
 * @param {string} str
 * @returns {string}
 */
function escapeHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}


// ============================================================
// 4. CONTADOR DE DIAS PARA ATIVIDADES
// ============================================================

/**
 * Retorna quantos dias faltam (ou passaram) para uma data ISO.
 * @param {string} dataISO - "YYYY-MM-DD"
 * @returns {{ dias: number, texto: string, passou: boolean }}
 */
function diasParaAtividade(dataISO) {
  const hoje    = new Date(); hoje.setHours(0, 0, 0, 0);
  const alvo    = new Date(dataISO); alvo.setHours(0, 0, 0, 0);
  const diff    = Math.round((alvo - hoje) / 86400000);
  const passou  = diff < 0;

  let texto;
  if (diff === 0)       texto = 'Hoje!';
  else if (diff === 1)  texto = 'Amanhã';
  else if (diff === -1) texto = 'Ontem';
  else if (passou)      texto = `Passou há ${Math.abs(diff)} dias`;
  else                  texto = `Em ${diff} dias`;

  return { dias: diff, texto, passou };
}

/**
 * Injeta labels de "Em X dias" em todas as células de data da tabela de atividades.
 * @param {string} seletorTabela
 */
function injetarContadorDias(seletorTabela = '.table tbody') {
  const tbody = document.querySelector(seletorTabela);
  if (!tbody) return;

  tbody.querySelectorAll('tr').forEach(tr => {
    const tdData = tr.querySelector('td:first-child');
    if (!tdData) return;

    // Data no formato DD/MM/YYYY → converte para YYYY-MM-DD
    const partes = tdData.textContent.trim().split('/');
    if (partes.length !== 3) return;
    const iso = `${partes[2]}-${partes[1]}-${partes[0]}`;

    const { texto, passou } = diasParaAtividade(iso);
    const badge = document.createElement('span');
    badge.style.cssText = `
      display:block; font-size:0.72rem; margin-top:3px;
      color: ${passou ? '#e74c3c' : '#a78bfa'};
      font-weight: bold;
    `;
    badge.textContent = texto;
    tdData.appendChild(badge);
  });
}


// ============================================================
// 5. MINI CALENDÁRIO INTERATIVO
// ============================================================

/**
 * Renderiza um mini calendário mensal em um elemento, destacando
 * os dias que têm atividades.
 *
 * @param {string}   seletorContainer - onde renderizar o calendário
 * @param {Date}     mes              - mês a exibir
 * @param {string[]} datasAtividades  - array de datas ISO com atividades
 * @param {function} [onClickDia]     - callback(data ISO) ao clicar num dia
 */
function renderizarMiniCalendario(seletorContainer, mes, datasAtividades = [], onClickDia = null) {
  const container = document.querySelector(seletorContainer);
  if (!container) return;

  const diasSemana = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
  const mesesPT = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                   'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

  const ano       = mes.getFullYear();
  const numMes    = mes.getMonth();
  const primeiroDia = new Date(ano, numMes, 1).getDay(); // 0=Dom
  const totalDias   = new Date(ano, numMes + 1, 0).getDate();

  // Normalizar datas de atividades para comparação
  const setDatas = new Set(datasAtividades.map(d => d.split('T')[0]));

  const hoje = new Date().toISOString().split('T')[0];

  let html = `
    <div class="fh-cal-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <button class="fh-cal-prev" style="background:rgba(255,255,255,.15);border:none;color:#fff;padding:4px 10px;border-radius:6px;cursor:pointer;">‹</button>
      <strong>${mesesPT[numMes]} ${ano}</strong>
      <button class="fh-cal-next" style="background:rgba(255,255,255,.15);border:none;color:#fff;padding:4px 10px;border-radius:6px;cursor:pointer;">›</button>
    </div>
    <div class="fh-cal-grid" style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px;text-align:center;">
  `;

  // Cabeçalho dos dias
  diasSemana.forEach(d => {
    html += `<div style="font-size:.75rem;opacity:.6;padding:2px;">${d}</div>`;
  });

  // Células vazias antes do primeiro dia
  for (let i = 0; i < primeiroDia; i++) {
    html += `<div></div>`;
  }

  // Dias do mês
  for (let dia = 1; dia <= totalDias; dia++) {
    const isoData   = `${ano}-${String(numMes + 1).padStart(2,'0')}-${String(dia).padStart(2,'0')}`;
    const temAtiv   = setDatas.has(isoData);
    const eHoje     = isoData === hoje;

    const bg      = eHoje    ? '#a78bfa'
                  : temAtiv  ? 'rgba(0,208,132,.25)'
                  :            'transparent';
    const border  = temAtiv && !eHoje ? '1px solid #a78bfa' : 'none';
    const cursor  = onClickDia ? 'pointer' : 'default';
    const title   = temAtiv ? 'Tem atividade neste dia' : '';

    html += `
      <div class="fh-cal-dia"
           data-data="${isoData}"
           title="${title}"
           style="
             padding:5px 2px;border-radius:6px;font-size:.85rem;
             background:${bg};border:${border};cursor:${cursor};
             position:relative;transition:background .2s;
           ">
        ${dia}
        ${temAtiv && !eHoje ? '<span style="display:block;width:4px;height:4px;background:#a78bfa;border-radius:50%;margin:1px auto 0;"></span>' : ''}
      </div>
    `;
  }

  html += `</div>`;
  container.innerHTML = html;

  // Navegação entre meses
  const mesAtual = new Date(mes);

  container.querySelector('.fh-cal-prev')?.addEventListener('click', () => {
    mesAtual.setMonth(mesAtual.getMonth() - 1);
    renderizarMiniCalendario(seletorContainer, new Date(mesAtual), datasAtividades, onClickDia);
  });
  container.querySelector('.fh-cal-next')?.addEventListener('click', () => {
    mesAtual.setMonth(mesAtual.getMonth() + 1);
    renderizarMiniCalendario(seletorContainer, new Date(mesAtual), datasAtividades, onClickDia);
  });

  // Clique nos dias
  if (onClickDia) {
    container.querySelectorAll('.fh-cal-dia').forEach(cel => {
      cel.addEventListener('click', () => onClickDia(cel.dataset.data));
    });
  }
}


// ============================================================
// 6. CONFIRMAÇÃO ELEGANTE (substitui o confirm() nativo)
// ============================================================

/**
 * Exibe um modal de confirmação personalizado.
 * @param {string}   mensagem
 * @param {function} onConfirmar  - chamado ao confirmar
 * @param {function} [onCancelar] - chamado ao cancelar
 */
function confirmarAcao(mensagem, onConfirmar, onCancelar = null) {
  // Remove modal anterior se existir
  document.getElementById('fh-modal-confirm')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'fh-modal-confirm';
  overlay.style.cssText = `
    position:fixed;inset:0;background:rgba(0,0,0,.6);
    display:flex;align-items:center;justify-content:center;z-index:10000;
    animation:fadeIn .2s ease;
  `;

  overlay.innerHTML = `
    <style>@keyframes fadeIn{from{opacity:0}to{opacity:1}}
    @keyframes popIn{from{transform:scale(.9);opacity:0}to{transform:scale(1);opacity:1}}</style>
    <div style="
      background:linear-gradient(135deg,#1a0a3e,#2d1060);
      border:1px solid rgba(0,208,132,.3);
      border-radius:16px;padding:32px;max-width:360px;width:90%;
      animation:popIn .25s ease;text-align:center;color:#fff;
    ">
      <div style="font-size:2rem;margin-bottom:12px;">⚠️</div>
      <p style="margin-bottom:24px;line-height:1.5;">${escapeHTML(mensagem)}</p>
      <div style="display:flex;gap:12px;justify-content:center;">
        <button id="fh-confirm-ok" style="
          background:#e74c3c;color:#fff;border:none;padding:10px 28px;
          border-radius:8px;cursor:pointer;font-weight:bold;font-size:1rem;
        ">Confirmar</button>
        <button id="fh-confirm-cancel" style="
          background:rgba(255,255,255,.15);color:#fff;border:none;
          padding:10px 28px;border-radius:8px;cursor:pointer;font-size:1rem;
        ">Cancelar</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);

  overlay.querySelector('#fh-confirm-ok').addEventListener('click', () => {
    overlay.remove();
    onConfirmar();
  });

  overlay.querySelector('#fh-confirm-cancel').addEventListener('click', () => {
    overlay.remove();
    onCancelar?.();
  });

  overlay.addEventListener('click', e => {
    if (e.target === overlay) { overlay.remove(); onCancelar?.(); }
  });
}


// ============================================================
// 7. INICIALIZAÇÃO AUTOMÁTICA POR PÁGINA
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // --- Página de ATIVIDADES ---
  const formAtiv = document.querySelector('form[action*="salvar_atividade"]');
  if (formAtiv) {
    // Validação antes de enviar
    formAtiv.addEventListener('submit', e => {
      if (!validarFormularioAtividade(formAtiv)) e.preventDefault();
    });

    // Criar campo de busca dinamicamente
    const tableContainer = document.querySelector('.table-responsive');
    if (tableContainer) {
      const searchWrapper = document.createElement('div');
      searchWrapper.style.cssText = 'margin-bottom:12px;display:flex;gap:10px;align-items:center;';
      searchWrapper.innerHTML = `
        <input id="busca-atividade" type="text" placeholder="🔍 Buscar atividade..." 
          style="flex:1;padding:9px 14px;border-radius:8px;border:none;background:rgba(255,255,255,.15);
                 color:#fff;font-size:.95rem;">
        <button data-status="" style="
          background:rgba(255,255,255,.15);color:#fff;border:none;padding:9px 14px;
          border-radius:8px;cursor:pointer;font-size:.85rem;">Todos</button>
        <button data-status="pendente" style="
          background:rgba(255,153,0,.2);color:#ffa500;border:1px solid rgba(255,153,0,.4);
          padding:9px 14px;border-radius:8px;cursor:pointer;font-size:.85rem;">Pendentes</button>
        <button data-status="processo" style="
          background:rgba(59,158,255,.2);color:#3b9eff;border:1px solid rgba(59,158,255,.4);
          padding:9px 14px;border-radius:8px;cursor:pointer;font-size:.85rem;">Em Processo</button>
        <button data-status="concluída" style="
          background:rgba(167,139,250,.2);color:#a78bfa;border:1px solid rgba(167,139,250,.4);
          padding:9px 14px;border-radius:8px;cursor:pointer;font-size:.85rem;">Concluídas</button>
      `;
      tableContainer.parentNode.insertBefore(searchWrapper, tableContainer);

      iniciarBuscaAtividades('#busca-atividade', '.table tbody');
      iniciarFiltroStatus('[data-status]', '.table tbody');
    }

    // Contador de dias para cada atividade
    injetarContadorDias('.table tbody');

    // Substituir confirm() nativo nos botões de excluir
    document.querySelectorAll('.btn-danger[onclick]').forEach(btn => {
      const href = btn.getAttribute('href');
      btn.removeAttribute('onclick');
      btn.addEventListener('click', e => {
        e.preventDefault();
        confirmarAcao('Deseja realmente excluir esta atividade? Esta ação não pode ser desfeita.', () => {
          window.location.href = href;
        });
      });
    });
  }

  // --- Página de MEMBROS ---
  const formMembro = document.querySelector('form[action*="salvar_membro"]');
  if (formMembro) {
    // Bloqueia datas futuras no campo de nascimento
    configurarInputData('[name="data_nascimento"]', false);

    formMembro.addEventListener('submit', e => {
      if (!validarFormularioMembro(formMembro)) e.preventDefault();
    });

    // Exibe a idade calculada em tempo real ao preencher data de nascimento
    const inputNasc = formMembro.querySelector('[name="data_nascimento"]');
    if (inputNasc) {
      const hintIdade = document.createElement('small');
      hintIdade.style.cssText = 'display:block;margin-top:4px;color:#a78bfa;min-height:18px;';
      inputNasc.parentNode.appendChild(hintIdade);

      inputNasc.addEventListener('change', () => {
        if (!inputNasc.value) { hintIdade.textContent = ''; return; }
        const idade = calcularIdade(inputNasc.value);
        hintIdade.textContent = idade >= 0 ? `🎂 ${idade} anos` : 'Data inválida';
      });
    }
  }

  // --- Página de CALENDÁRIO ---
  if (document.querySelector('.calendario-list')) {
    // Lê os data-dates injetados pelo PHP (precisa adicionar no HTML — veja abaixo)
    const datasEl = document.getElementById('fh-datas-atividades');
    const datasAtiv = datasEl ? JSON.parse(datasEl.textContent || '[]') : [];

    // Injeta o mini calendário antes da lista
    const main = document.querySelector('.content');
    if (main) {
      const calContainer = document.createElement('div');
      calContainer.id = 'fh-mini-cal';
      calContainer.style.cssText = `
        background:rgba(255,255,255,.08);
        border-radius:12px;padding:16px;max-width:320px;
        margin-bottom:24px;
      `;
      main.querySelector('.card')?.before(calContainer);

      renderizarMiniCalendario('#fh-mini-cal', new Date(), datasAtiv, (data) => {
        mostrarToast(`Selecionado: ${formatarDataBR(data)}`, 'info');
        // Scroll até o card do mês correspondente
        const [ano, mes] = data.split('-');
        const target = document.querySelector(`.card h2`);
        target?.scrollIntoView({ behavior: 'smooth' });
      });
    }
  }

  // --- Todas as páginas: campos de data de atividade não podem ser passado ---
  // (Remova essa linha se quiser permitir datas passadas)
  // configurarInputData('form[action*="salvar_atividade"] [name="data"]', true);

  // --- Todas as páginas: feedback de formulários enviados ---
  const url = new URL(window.location.href);
  const status = url.searchParams.get('status');
  if (status === 'sucesso')  mostrarToast('Operação realizada com sucesso!', 'sucesso');
  if (status === 'erro')     mostrarToast('Ocorreu um erro. Tente novamente.', 'erro');
  if (status === 'excluido') mostrarToast('Item excluído com sucesso.', 'info');

});
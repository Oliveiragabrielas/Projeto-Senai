<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

// Ranking geral por membro (total de pontos)
$ranking = [];
$stmtRank = $conn->prepare("
    SELECT m.id_membro, m.nome, m.papel,
           COALESCE(SUM(p.pontos), 0) AS total_pontos,
           COUNT(p.id_pontuacao) AS atividades_concluidas
    FROM membros m
    LEFT JOIN pontuacao p ON p.id_membro = m.id_membro
    WHERE m.id_usuario = ?
    GROUP BY m.id_membro, m.nome, m.papel
    ORDER BY total_pontos DESC, atividades_concluidas DESC
");
if ($stmtRank) {
    $stmtRank->bind_param("i", $id_usuario);
    $stmtRank->execute();
    $res = $stmtRank->get_result();
    while ($row = $res->fetch_assoc()) $ranking[] = $row;
    $stmtRank->close();
}

// Histórico de pontos recentes (todas as atividades concluídas)
$historico = [];
$stmtHist = $conn->prepare("
    SELECT p.pontos, p.motivo, p.criado_em,
           m.nome AS nome_membro, m.papel,
           a.descricao, a.prioridade, a.tipo
    FROM pontuacao p
    INNER JOIN membros m ON p.id_membro = m.id_membro
    INNER JOIN atividades a ON p.id_ativ = a.id_ativ
    WHERE m.id_usuario = ?
    ORDER BY p.criado_em DESC
    LIMIT 20
");
if ($stmtHist) {
    $stmtHist->bind_param("i", $id_usuario);
    $stmtHist->execute();
    $res = $stmtHist->get_result();
    while ($row = $res->fetch_assoc()) $historico[] = $row;
    $stmtHist->close();
}

// Total geral de pontos da família
$totalFamilia = array_sum(array_column($ranking, 'total_pontos'));

// Função de medalha
function medalha(int $pos): string {
    return match($pos) { 1 => '🥇', 2 => '🥈', 3 => '🥉', default => "#$pos" };
}

// Nível baseado em pontos
function nivel(int $pts): array {
    if ($pts >= 500) return ['name' => 'Lendário',  'color' => '#a78bfa', 'icon' => '👑', 'next' => null,  'progress' => 100];
    if ($pts >= 300) return ['name' => 'Mestre',    'color' => '#f39c12', 'icon' => '⭐', 'next' => 500,   'progress' => (int)(($pts-300)/2)];
    if ($pts >= 150) return ['name' => 'Avançado',  'color' => '#3b9eff', 'icon' => '🔵', 'next' => 300,   'progress' => (int)(($pts-150)/1.5)];
    if ($pts >= 50)  return ['name' => 'Iniciante', 'color' => '#27ae60', 'icon' => '🟢', 'next' => 150,   'progress' => (int)(($pts-50))];
    return              ['name' => 'Novato',    'color' => '#aaa',    'icon' => '⚪', 'next' => 50,    'progress' => (int)($pts*2)];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ranking - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ===== RANKING PAGE ===== */
        .ranking-podio {
            display: flex;
            align-items: flex-end;
            justify-content: center;
            gap: 16px;
            margin: 32px 0 40px;
        }
        .podio-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            flex: 1;
            max-width: 160px;
        }
        .podio-item:nth-child(1) { order: 2; }
        .podio-item:nth-child(2) { order: 1; }
        .podio-item:nth-child(3) { order: 3; }

        .podio-avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            font-weight: 800;
            color: #fff;
            position: relative;
            transition: transform 0.2s;
        }
        .podio-avatar.pos-1 {
            width: 80px;
            height: 80px;
            font-size: 2rem;
            background: linear-gradient(135deg, #f5d060, #e8a020);
            box-shadow: 0 0 24px rgba(245,208,96,0.5);
        }
        .podio-avatar.pos-2 {
            background: linear-gradient(135deg, #c0d0e8, #8899bb);
            box-shadow: 0 0 16px rgba(192,208,232,0.4);
        }
        .podio-avatar.pos-3 {
            background: linear-gradient(135deg, #d8a080, #a06040);
            box-shadow: 0 0 12px rgba(216,160,128,0.3);
        }
        .podio-avatar.pos-other {
            background: rgba(255,255,255,0.12);
            font-size: 1.3rem;
        }
        .podio-medal {
            position: absolute;
            top: -10px;
            right: -6px;
            font-size: 1.4rem;
        }
        .podio-base {
            width: 100%;
            border-radius: 12px 12px 0 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            padding: 12px 8px;
            font-weight: 700;
        }
        .podio-base.pos-1 {
            height: 100px;
            background: linear-gradient(160deg, rgba(245,208,96,0.25), rgba(232,160,32,0.15));
            border: 1px solid rgba(245,208,96,0.4);
        }
        .podio-base.pos-2 {
            height: 75px;
            background: linear-gradient(160deg, rgba(192,208,232,0.2), rgba(136,153,187,0.1));
            border: 1px solid rgba(192,208,232,0.35);
        }
        .podio-base.pos-3 {
            height: 55px;
            background: linear-gradient(160deg, rgba(216,160,128,0.2), rgba(160,96,64,0.1));
            border: 1px solid rgba(216,160,128,0.3);
        }
        .podio-nome {
            font-size: 0.85rem;
            color: var(--text-primary);
            font-weight: 700;
            text-align: center;
            word-break: break-word;
        }
        .podio-pts {
            font-size: 1.1rem;
            font-weight: 800;
            color: var(--accent);
        }

        /* Lista de ranking */
        .ranking-list { display: flex; flex-direction: column; gap: 10px; }
        .ranking-row {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 14px 18px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--r-md);
            transition: border-color 0.2s, transform 0.15s;
        }
        .ranking-row:hover { border-color: var(--border-strong); transform: translateX(3px); }
        .ranking-row.destaque-1 { border-color: rgba(245,208,96,0.5); background: rgba(245,208,96,0.06); }
        .ranking-row.destaque-2 { border-color: rgba(192,208,232,0.4); background: rgba(192,208,232,0.05); }
        .ranking-row.destaque-3 { border-color: rgba(216,160,128,0.4); background: rgba(216,160,128,0.05); }

        .rank-pos {
            font-size: 1.3rem;
            min-width: 36px;
            text-align: center;
            font-weight: 800;
        }
        .rank-avatar {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            font-weight: 800;
            color: #fff;
            flex-shrink: 0;
            background: linear-gradient(135deg, var(--accent-dark), var(--accent));
        }
        .rank-info { flex: 1; min-width: 0; }
        .rank-nome { font-weight: 700; font-size: 1rem; color: var(--text-primary); }
        .rank-papel { font-size: 0.8rem; color: var(--text-muted); }

        /* Nível + barra */
        .rank-nivel {
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 5px;
        }
        .nivel-label {
            font-size: 0.75rem;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 20px;
        }
        .nivel-bar-wrap {
            flex: 1;
            height: 6px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        .nivel-bar-fill {
            height: 100%;
            border-radius: 10px;
            transition: width 1s cubic-bezier(.4,0,.2,1);
        }
        .nivel-bar-next { font-size: 0.7rem; color: var(--text-muted); white-space: nowrap; }

        .rank-pts-block { text-align: right; flex-shrink: 0; }
        .rank-pts { font-size: 1.3rem; font-weight: 800; color: var(--accent); }
        .rank-pts-label { font-size: 0.72rem; color: var(--text-muted); }
        .rank-concl { font-size: 0.78rem; color: var(--text-secondary); margin-top: 2px; }

        /* Badges de prioridade */
        .badge-prioridade {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 3px 9px; border-radius: 20px; font-size: 0.78rem;
            font-weight: 700; white-space: nowrap;
        }
        .badge-prioridade.alta  { background: rgba(231,76,60,.18); color: #e74c3c; border:1px solid rgba(231,76,60,.45); }
        .badge-prioridade.media { background: rgba(243,156,18,.18); color: #f39c12; border:1px solid rgba(243,156,18,.45); }
        .badge-prioridade.baixa { background: rgba(39,174,96,.18);  color: #27ae60; border:1px solid rgba(39,174,96,.45); }
        .badge-prioridade .dot  { width:7px; height:7px; border-radius:50%; }
        .badge-prioridade.alta .dot  { background:#e74c3c; box-shadow:0 0 4px #e74c3c; }
        .badge-prioridade.media .dot { background:#f39c12; }
        .badge-prioridade.baixa .dot { background:#27ae60; }

        /* Histórico */
        .hist-list { display: flex; flex-direction: column; gap: 8px; }
        .hist-item {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 14px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--r-sm);
        }
        .hist-pontos {
            font-size: 1rem; font-weight: 800;
            min-width: 48px; text-align: center;
            color: var(--accent);
        }
        .hist-pontos span { font-size: 0.7rem; font-weight: 400; color: var(--text-muted); display: block; }
        .hist-info { flex: 1; min-width: 0; }
        .hist-desc { font-size: 0.88rem; font-weight: 700; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .hist-meta { font-size: 0.75rem; color: var(--text-muted); margin-top: 2px; }
        .hist-data { font-size: 0.75rem; color: var(--text-muted); white-space: nowrap; flex-shrink: 0; }

        /* Stat total */
        .familia-total {
            display: flex; align-items: center; justify-content: center;
            gap: 12px; padding: 20px;
            background: linear-gradient(135deg, rgba(167,139,250,0.12), rgba(124,58,237,0.06));
            border: 1px solid rgba(167,139,250,0.3);
            border-radius: var(--r-lg);
            margin-bottom: 28px;
        }
        .familia-total-icon { font-size: 2.4rem; }
        .familia-total-info h3 { font-size: 0.85rem; color: var(--text-muted); margin: 0; font-weight: 500; }
        .familia-total-pts { font-size: 2rem; font-weight: 800; color: var(--accent); margin: 0; line-height: 1; }

        @media (max-width: 600px) {
            .ranking-podio { gap: 8px; }
            .podio-avatar.pos-1 { width: 64px; height: 64px; font-size: 1.5rem; }
            .nivel-bar-wrap { display: none; }
        }
    </style>
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>🏆 Ranking da Família</h1>
        <p class="subtitle">Pontos ganhos ao concluir atividades — Alta: 30pts · Média: 20pts · Baixa: 10pts</p>
    </div>

    <?= exibirAlertas() ?>

    <!-- Total família -->
    <div class="familia-total">
        <div class="familia-total-icon">🏠</div>
        <div class="familia-total-info">
            <h3>Total de pontos da família</h3>
            <p class="familia-total-pts"><?= number_format($totalFamilia) ?> pts</p>
        </div>
    </div>

    <?php if (empty($ranking)): ?>
        <div class="card">
            <div class="empty-state">
                <p>🏆 Nenhum membro cadastrado ainda. <a href="membros.php">Cadastre membros</a> e comece a pontuar!</p>
            </div>
        </div>
    <?php else: ?>

    <!-- Pódio (top 3) -->
    <?php if (count($ranking) >= 2): ?>
    <div class="card">
        <div class="card-header"><h2>🥇 Pódio</h2></div>
        <div class="ranking-podio">
            <?php foreach (array_slice($ranking, 0, 3) as $i => $m):
                $pos = $i + 1;
                $inicial = mb_strtoupper(mb_substr(trim($m['nome']), 0, 1, 'UTF-8'), 'UTF-8');
                $avatarClass = "pos-$pos";
                if ($pos > 3) $avatarClass = 'pos-other';
                $nv = nivel((int)$m['total_pontos']);
            ?>
            <div class="podio-item">
                <div class="podio-avatar <?= $avatarClass ?>">
                    <?= $inicial ?>
                    <span class="podio-medal"><?= medalha($pos) ?></span>
                </div>
                <div class="podio-nome"><?= esc($m['nome']) ?></div>
                <div class="podio-base <?= $avatarClass ?>">
                    <div class="podio-pts"><?= number_format((int)$m['total_pontos']) ?> pts</div>
                    <div style="font-size:0.72rem;color:var(--text-muted)"><?= $nv['icon'] ?> <?= $nv['name'] ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Lista completa -->
    <div class="card">
        <div class="card-header"><h2>📋 Classificação Completa</h2></div>
        <div class="ranking-list">
            <?php foreach ($ranking as $i => $m):
                $pos = $i + 1;
                $inicial = mb_strtoupper(mb_substr(trim($m['nome']), 0, 1, 'UTF-8'), 'UTF-8');
                $nv = nivel((int)$m['total_pontos']);
                $destaqueClass = $pos <= 3 ? "destaque-$pos" : '';
            ?>
            <div class="ranking-row <?= $destaqueClass ?>">
                <div class="rank-pos"><?= medalha($pos) ?></div>
                <div class="rank-avatar"><?= $inicial ?></div>
                <div class="rank-info">
                    <div class="rank-nome"><?= esc($m['nome']) ?></div>
                    <div class="rank-papel"><?= esc($m['papel']) ?></div>
                    <div class="rank-nivel">
                        <span class="nivel-label" style="background:<?= $nv['color'] ?>22; color:<?= $nv['color'] ?>; border:1px solid <?= $nv['color'] ?>44;">
                            <?= $nv['icon'] ?> <?= $nv['name'] ?>
                        </span>
                        <div class="nivel-bar-wrap" title="Progresso para o próximo nível">
                            <div class="nivel-bar-fill" style="width:<?= min(100, $nv['progress']) ?>%; background:<?= $nv['color'] ?>;"></div>
                        </div>
                        <?php if ($nv['next']): ?>
                            <span class="nivel-bar-next">→ <?= $nv['next'] ?>pts</span>
                        <?php else: ?>
                            <span class="nivel-bar-next" style="color:var(--accent)">Nível máximo!</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="rank-pts-block">
                    <div class="rank-pts"><?= number_format((int)$m['total_pontos']) ?></div>
                    <div class="rank-pts-label">pontos</div>
                    <div class="rank-concl">✅ <?= (int)$m['atividades_concluidas'] ?> concluída<?= $m['atividades_concluidas'] != 1 ? 's' : '' ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php endif; ?>

    <!-- Histórico de pontos -->
    <?php if (!empty($historico)): ?>
    <div class="card">
        <div class="card-header">
            <h2>📜 Histórico de Pontos</h2>
            <span style="font-size:0.82rem;color:var(--text-muted)">Últimas 20 conquistas</span>
        </div>
        <div class="hist-list">
            <?php foreach ($historico as $h):
                $prio = $h['prioridade'];
                $prioClass = match($prio) { 'Alta' => 'alta', 'Média' => 'media', 'Baixa' => 'baixa', default => 'baixa' };
                $prioIcon  = match($prio) { 'Alta' => '🔴', 'Média' => '🟡', 'Baixa' => '🟢', default => '⚪' };
            ?>
            <div class="hist-item">
                <div class="hist-pontos">
                    +<?= (int)$h['pontos'] ?>
                    <span>pts</span>
                </div>
                <div class="hist-info">
                    <div class="hist-desc"><?= esc($h['descricao']) ?></div>
                    <div class="hist-meta">
                        👤 <?= esc($h['nome_membro']) ?> &bull;
                        <span class="badge-prioridade <?= $prioClass ?>" style="padding:1px 7px;font-size:0.7rem;">
                            <span class="dot"></span> <?= $prioIcon ?> <?= esc($prio) ?>
                        </span>
                        &bull; <?= esc($h['tipo']) ?>
                    </div>
                </div>
                <div class="hist-data"><?= date('d/m/Y', strtotime($h['criado_em'])) ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php elseif (!empty($ranking)): ?>
    <div class="card">
        <div class="empty-state">
            <p>⭐ Nenhuma atividade concluída ainda. Conclua atividades para ganhar pontos!</p>
            <a href="atividades.php" class="btn btn-primary">Ver Atividades</a>
        </div>
    </div>
    <?php endif; ?>

</main>
</body>
</html>

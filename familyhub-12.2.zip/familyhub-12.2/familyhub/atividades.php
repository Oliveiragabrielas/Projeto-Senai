<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/verifica_login.php";
require_once "includes/conexao.php";
require_once "includes/funcoes.php";

$id_usuario = (int)$_SESSION['usuario_id'];

$atividades = [];
$stmt = $conn->prepare("SELECT a.*, m.nome as nome_membro FROM atividades a INNER JOIN membros m ON a.id_membro = m.id_membro WHERE m.id_usuario = ? ORDER BY a.data ASC, a.horario ASC");
if ($stmt) {
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) $atividades[] = $row;
    $stmt->close();
}

$membros = [];
$stmtM = $conn->prepare("SELECT id_membro, nome FROM membros WHERE id_usuario = ? ORDER BY nome");
if ($stmtM) {
    $stmtM->bind_param("i", $id_usuario);
    $stmtM->execute();
    $res = $stmtM->get_result();
    while ($row = $res->fetch_assoc()) $membros[] = $row;
    $stmtM->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividades - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* ===== BADGES DE PRIORIDADE ===== */
        .badge-prioridade {
            display: inline-flex; align-items: center; gap: 5px;
            padding: 3px 10px; border-radius: 20px; font-size: 0.78rem;
            font-weight: 700; letter-spacing: 0.03em; white-space: nowrap;
        }
        .badge-prioridade.alta  { background:rgba(231,76,60,.15);  color:#e74c3c; border:1px solid rgba(231,76,60,.4);  box-shadow:0 0 8px rgba(231,76,60,.15); }
        .badge-prioridade.media { background:rgba(243,156,18,.15); color:#f39c12; border:1px solid rgba(243,156,18,.4); }
        .badge-prioridade.baixa { background:rgba(39,174,96,.15);  color:#27ae60; border:1px solid rgba(39,174,96,.4);  }
        .badge-prioridade .dot  { width:7px; height:7px; border-radius:50%; flex-shrink:0; }
        .badge-prioridade.alta .dot  { background:#e74c3c; box-shadow:0 0 4px #e74c3c; }
        .badge-prioridade.media .dot { background:#f39c12; }
        .badge-prioridade.baixa .dot { background:#27ae60; }

        /* ===== FILTROS ===== */
        .ativ-filtros { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:20px; }
        .filtro-btn {
            padding:6px 14px; border-radius:20px; font-size:0.8rem; font-weight:600;
            cursor:pointer; border:1px solid var(--border); background:var(--bg-card);
            color:var(--text-secondary); transition:all 0.2s;
        }
        .filtro-btn:hover, .filtro-btn.ativo {
            background:var(--accent); color:#fff;
            border-color:var(--accent); box-shadow:0 0 12px rgba(167,139,250,0.3);
        }
        .filtro-btn.ativo-pendente  { background:#f39c12 !important; border-color:#f39c12 !important; color:#fff !important; }
        .filtro-btn.ativo-processo  { background:#3b9eff !important; border-color:#3b9eff !important; color:#fff !important; }
        .filtro-btn.ativo-concluida { background:#27ae60 !important; border-color:#27ae60 !important; color:#fff !important; }

        /* ===== CONTADORES ===== */
        .ativ-counters { display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; }
        .ativ-counter {
            flex:1; min-width:80px; padding:12px 14px; border-radius:var(--r-md);
            background:var(--bg-card); border:1px solid var(--border);
            text-align:center; cursor:pointer; transition:all 0.2s; user-select:none;
        }
        .ativ-counter:hover { border-color:var(--border-strong); transform:translateY(-1px); }
        .ativ-counter .cnt-num { font-size:1.6rem; font-weight:800; line-height:1; }
        .ativ-counter .cnt-lbl { font-size:0.7rem; color:var(--text-muted); margin-top:3px; }
        .ativ-counter.pendente .cnt-num  { color:#f39c12; }
        .ativ-counter.processo .cnt-num  { color:#3b9eff; }
        .ativ-counter.concluida .cnt-num { color:#27ae60; }
        .ativ-counter.ativo { border-color: var(--accent); }

        /* ===== GRID DE CARDS ===== */
        .ativ-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill, minmax(290px, 1fr));
            gap:14px;
        }

        /* ===== CARD DE ATIVIDADE ===== */
        .ativ-card {
            background:var(--bg-card); border:1px solid var(--border);
            border-radius:var(--r-lg); overflow:hidden;
            transition:transform 0.2s, box-shadow 0.2s, border-color 0.2s;
            display:flex; flex-direction:column; position:relative;
        }
        .ativ-card:hover { transform:translateY(-3px); box-shadow:var(--shadow-md); border-color:var(--border-strong); }
        .ativ-card.status-concluída, .ativ-card.status-concluida { opacity:0.65; }
        .ativ-card.status-concluída:hover, .ativ-card.status-concluida:hover { opacity:1; }

        /* Barra lateral colorida por prioridade */
        .ativ-card::before {
            content:''; position:absolute; left:0; top:0; bottom:0; width:4px;
        }
        .ativ-card.prio-alta::before  { background:#e74c3c; box-shadow:2px 0 10px rgba(231,76,60,.3); }
        .ativ-card.prio-media::before { background:#f39c12; box-shadow:2px 0 10px rgba(243,156,18,.2); }
        .ativ-card.prio-baixa::before { background:#27ae60; box-shadow:2px 0 10px rgba(39,174,96,.2); }

        .ativ-card-header {
            padding:15px 16px 8px 20px;
            display:flex; align-items:flex-start; justify-content:space-between; gap:10px;
        }
        .ativ-card-titulo {
            font-size:0.95rem; font-weight:700; color:var(--text-primary);
            line-height:1.4; flex:1; min-width:0;
        }
        .ativ-card.status-concluída .ativ-card-titulo,
        .ativ-card.status-concluida .ativ-card-titulo {
            text-decoration:line-through; color:var(--text-muted);
        }

        .ativ-card-body { padding:0 16px 12px 20px; display:flex; flex-direction:column; gap:8px; flex:1; }

        .ativ-card-meta { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
        .ativ-meta-item { display:inline-flex; align-items:center; gap:4px; font-size:0.77rem; color:var(--text-secondary); }

        .ativ-membro { display:flex; align-items:center; gap:7px; margin-top:2px; }
        .ativ-membro-avatar {
            width:26px; height:26px; border-radius:50%;
            background:linear-gradient(135deg, var(--accent-dark), var(--accent));
            display:flex; align-items:center; justify-content:center;
            font-size:0.72rem; font-weight:800; color:#fff; flex-shrink:0;
        }
        .ativ-membro-nome { font-size:0.82rem; font-weight:600; color:var(--text-secondary); }

        .ativ-card-footer {
            padding:10px 16px 13px 20px; border-top:1px solid var(--border);
            display:flex; align-items:center; justify-content:space-between; gap:8px; flex-wrap:wrap;
        }
        .ativ-card-acoes { display:flex; gap:6px; }
        .ativ-card-acoes .btn { font-size:0.77rem; padding:5px 11px; }

        .tipo-badge {
            display:inline-flex; align-items:center; gap:4px;
            padding:2px 8px; border-radius:6px; font-size:0.72rem; font-weight:600;
            background:rgba(255,255,255,0.07); color:var(--text-muted); border:1px solid var(--border);
        }

        .ativ-empty { display:flex; flex-direction:column; align-items:center; padding:50px 20px; gap:10px; color:var(--text-muted); }

        @media (max-width:600px) { .ativ-grid { grid-template-columns:1fr; } }
    </style>
</head>
<body>

<?php include "includes/menu.php"; ?>

<main class="content">
    <div class="page-header">
        <h1>📋 Atividades da Família</h1>
        <p class="subtitle">Cadastre e acompanhe as atividades da família</p>
    </div>

    <?= exibirAlertas() ?>

    <div class="card">
        <div class="card-header"><h2>Nova Atividade</h2></div>

        <form action="acoes/salvar_atividade.php" method="POST" class="form-horizontal">
            <div class="form-row">
                <div class="form-group">
                    <label for="descricao">Descrição *</label>
                    <input type="text" id="descricao" name="descricao" placeholder="Ex: Reunião escolar" required maxlength="200">
                </div>
                <div class="form-group">
                    <label for="data">Data *</label>
                    <input type="date" id="data" name="data" required>
                </div>
                <div class="form-group">
                    <label for="horario">Horário *</label>
                    <input type="time" id="horario" name="horario" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="tipo">Tipo *</label>
                    <select id="tipo" name="tipo" required>
                        <option value="">Selecione...</option>
                        <option value="Escolar">Escolar</option>
                        <option value="Esporte">Esporte</option>
                        <option value="Social">Social</option>
                        <option value="Casa">Casa</option>
                        <option value="Saude">Saúde</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="prioridade">Prioridade</label>
                    <select id="prioridade" name="prioridade">
                        <option value="Baixa">Baixa</option>
                        <option value="Média" selected>Média</option>
                        <option value="Alta">Alta</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="Pendente">Pendente</option>
                        <option value="Processo">Em Processo</option>
                        <option value="Concluída">Concluída</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="id_membro">Membro *</label>
                    <select id="id_membro" name="id_membro" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($membros as $m): ?>
                            <option value="<?= (int)$m['id_membro'] ?>"><?= esc($m['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($membros)): ?>
                        <small class="form-hint">Nenhum membro. <a href="membros.php">Cadastre um membro</a> primeiro.</small>
                    <?php endif; ?>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" <?= empty($membros) ? 'disabled' : '' ?>>
                ➕ Cadastrar Atividade
            </button>
        </form>
    </div>

    <?php
    // Contadores por status
    $cntPendente  = count(array_filter($atividades, fn($a) => $a['status'] === 'Pendente'));
    $cntProcesso  = count(array_filter($atividades, fn($a) => $a['status'] === 'Processo'));
    $cntConcluida = count(array_filter($atividades, fn($a) => $a['status'] === 'Concluída'));

    // Ícones por tipo
    $tipoIcones = ['Escolar'=>'📚','Esporte'=>'⚽','Social'=>'🤝','Casa'=>'🏠','Saude'=>'💊','Outro'=>'📌','Saúde'=>'💊'];
    ?>

    <div class="card">
        <div class="card-header">
            <h2>Atividades <span style="color:var(--text-muted);font-weight:500;font-size:0.9rem">(<?= count($atividades) ?>)</span></h2>
        </div>

        <?php if (empty($atividades)): ?>
            <div class="ativ-empty">
                <span style="font-size:2.5rem">📋</span>
                <p style="margin:0;font-size:1rem">Nenhuma atividade cadastrada ainda.</p>
                <p style="margin:0;font-size:0.85rem">Use o formulário acima para adicionar a primeira!</p>
            </div>
        <?php else: ?>

            <!-- Contadores clicáveis -->
            <div class="ativ-counters">
                <div class="ativ-counter pendente" onclick="filtrar('Pendente')" id="cnt-pendente">
                    <div class="cnt-num"><?= $cntPendente ?></div>
                    <div class="cnt-lbl">⏳ Pendentes</div>
                </div>
                <div class="ativ-counter processo" onclick="filtrar('Processo')" id="cnt-processo">
                    <div class="cnt-num"><?= $cntProcesso ?></div>
                    <div class="cnt-lbl">🔄 Em Processo</div>
                </div>
                <div class="ativ-counter concluida" onclick="filtrar('Concluída')" id="cnt-concluida">
                    <div class="cnt-num"><?= $cntConcluida ?></div>
                    <div class="cnt-lbl">✅ Concluídas</div>
                </div>
            </div>

            <!-- Filtros -->
            <div class="ativ-filtros">
                <button class="filtro-btn ativo" onclick="filtrar('todos')" id="filtro-todos">Todos</button>
                <button class="filtro-btn" onclick="filtrar('Pendente')"  id="filtro-pendente">⏳ Pendentes</button>
                <button class="filtro-btn" onclick="filtrar('Processo')"  id="filtro-processo">🔄 Em Processo</button>
                <button class="filtro-btn" onclick="filtrar('Concluída')" id="filtro-concluida">✅ Concluídas</button>
            </div>

            <!-- Grid de cards -->
            <div class="ativ-grid" id="ativ-grid">
            <?php foreach ($atividades as $a):
                $prio      = $a['prioridade'];
                $prioClass = match($prio) { 'Alta'=>'alta','Média'=>'media','Baixa'=>'baixa', default=>'baixa' };
                $prioIcon  = match($prio) { 'Alta'=>'🔴','Média'=>'🟡','Baixa'=>'🟢', default=>'⚪' };
                $statusSlug = strtolower(str_replace('í','i', $a['status']));
                $tipoIcon  = $tipoIcones[$a['tipo']] ?? '📌';
                $inicial   = mb_strtoupper(mb_substr(trim($a['nome_membro']), 0, 1, 'UTF-8'), 'UTF-8');
            ?>
                <div class="ativ-card prio-<?= $prioClass ?> status-<?= esc($a['status']) ?>"
                     data-status="<?= esc($a['status']) ?>">

                    <!-- Cabeçalho -->
                    <div class="ativ-card-header">
                        <div class="ativ-card-titulo"><?= esc($a['descricao']) ?></div>
                        <span class="badge badge-<?= $statusSlug ?>" style="flex-shrink:0"><?= esc($a['status']) ?></span>
                    </div>

                    <!-- Corpo -->
                    <div class="ativ-card-body">
                        <div class="ativ-card-meta">
                            <span class="ativ-meta-item">📅 <?= formatarData($a['data']) ?></span>
                            <span style="color:var(--border)">·</span>
                            <span class="ativ-meta-item">🕐 <?= date('H:i', strtotime($a['horario'])) ?></span>
                        </div>
                        <div class="ativ-card-meta" style="gap:7px">
                            <span class="tipo-badge"><?= $tipoIcon ?> <?= esc($a['tipo']) ?></span>
                            <span class="badge-prioridade <?= $prioClass ?>">
                                <span class="dot"></span>
                                <?= $prioIcon ?> <?= esc($prio) ?>
                            </span>
                        </div>
                        <div class="ativ-membro">
                            <div class="ativ-membro-avatar"><?= $inicial ?></div>
                            <span class="ativ-membro-nome"><?= esc($a['nome_membro']) ?></span>
                        </div>
                    </div>

                    <!-- Rodapé com ações -->
                    <div class="ativ-card-footer">
                        <div style="font-size:0.72rem;color:var(--text-muted)">
                            ID #<?= (int)$a['id_ativ'] ?>
                        </div>
                        <div class="ativ-card-acoes">
                            <button type="button"
                                class="btn btn-sm btn-info btn-editar"
                                data-id="<?= (int)$a['id_ativ'] ?>"
                                data-descricao="<?= esc($a['descricao']) ?>"
                                data-data="<?= esc($a['data']) ?>"
                                data-horario="<?= esc(substr($a['horario'], 0, 5)) ?>"
                                data-tipo="<?= esc($a['tipo']) ?>"
                                data-prioridade="<?= esc($a['prioridade']) ?>"
                                data-status="<?= esc($a['status']) ?>"
                                data-membro="<?= (int)$a['id_membro'] ?>">
                                ✏️ Editar
                            </button>
                            <button type="button"
                                class="btn btn-sm btn-danger btn-excluir"
                                data-href="acoes/excluir_atividade.php?id=<?= (int)$a['id_ativ'] ?>">
                                🗑️
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>

            <div id="ativ-empty-filtro" style="display:none;text-align:center;padding:40px 20px;color:var(--text-muted)">
                <p style="font-size:1.3rem">🔍</p>
                <p>Nenhuma atividade com esse filtro.</p>
            </div>

        <?php endif; ?>
    </div>
</main>

<!-- ===== MODAL DE EDIÇÃO ===== -->
<div id="modal-editar" class="modal-overlay" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="modal-editar-titulo">
    <div class="modal">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
            <h2 id="modal-editar-titulo">Editar Atividade</h2>
            <button type="button" id="modal-fechar" class="btn btn-sm btn-secondary" aria-label="Fechar">✕</button>
        </div>

        <form action="acoes/editar_atividade.php" method="POST" id="form-editar">
            <input type="hidden" name="id_ativ" id="edit-id">

            <div class="form-row">
                <div class="form-group" style="grid-column:1/-1;">
                    <label for="edit-descricao">Descrição *</label>
                    <input type="text" id="edit-descricao" name="descricao" required maxlength="200" placeholder="Ex: Reunião escolar">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="edit-data">Data *</label>
                    <input type="date" id="edit-data" name="data" required>
                </div>
                <div class="form-group">
                    <label for="edit-horario">Horário *</label>
                    <input type="time" id="edit-horario" name="horario" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="edit-tipo">Tipo *</label>
                    <select id="edit-tipo" name="tipo" required>
                        <option value="">Selecione...</option>
                        <option value="Escolar">Escolar</option>
                        <option value="Esporte">Esporte</option>
                        <option value="Social">Social</option>
                        <option value="Casa">Casa</option>
                        <option value="Saude">Saúde</option>
                        <option value="Outro">Outro</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit-prioridade">Prioridade</label>
                    <select id="edit-prioridade" name="prioridade">
                        <option value="Baixa">Baixa</option>
                        <option value="Média">Média</option>
                        <option value="Alta">Alta</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit-status">Status</label>
                    <select id="edit-status" name="status">
                        <option value="Pendente">Pendente</option>
                        <option value="Processo">Em Processo</option>
                        <option value="Concluída">Concluída</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit-membro">Membro *</label>
                    <select id="edit-membro" name="id_membro" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($membros as $m): ?>
                            <option value="<?= (int)$m['id_membro'] ?>"><?= esc($m['nome']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" id="modal-cancelar" class="btn btn-secondary">Cancelar</button>
                <button type="submit" class="btn btn-primary">💾 Salvar Alterações</button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    // ===== FILTRO DE CARDS =====
    window.filtrar = function(status) {
        const cards   = document.querySelectorAll('.ativ-card');
        const grid    = document.getElementById('ativ-grid');
        const empty   = document.getElementById('ativ-empty-filtro');
        const btns    = document.querySelectorAll('.filtro-btn');
        let visiveis  = 0;

        cards.forEach(card => {
            const show = status === 'todos' || card.dataset.status === status;
            card.style.display = show ? '' : 'none';
            if (show) visiveis++;
        });

        // Atualiza botões de filtro
        btns.forEach(btn => {
            btn.classList.remove('ativo','ativo-pendente','ativo-processo','ativo-concluida');
        });
        const idMap = {'todos':'filtro-todos','Pendente':'filtro-pendente','Processo':'filtro-processo','Concluída':'filtro-concluida'};
        const classMap = {'todos':'ativo','Pendente':'ativo-pendente','Processo':'ativo-processo','Concluída':'ativo-concluida'};
        const activeBtn = document.getElementById(idMap[status]);
        if (activeBtn) activeBtn.classList.add(classMap[status] || 'ativo');

        if (grid)  grid.style.display  = visiveis > 0 ? '' : 'none';
        if (empty) empty.style.display = visiveis === 0 ? '' : 'none';
    };

    // ===== MODAL DE EDIÇÃO =====
    const modal = document.getElementById('modal-editar');

    function abrirModal(btn) {
        document.getElementById('edit-id').value         = btn.dataset.id;
        document.getElementById('edit-descricao').value  = btn.dataset.descricao;
        document.getElementById('edit-data').value       = btn.dataset.data;
        document.getElementById('edit-horario').value    = btn.dataset.horario;
        document.getElementById('edit-tipo').value       = btn.dataset.tipo;
        document.getElementById('edit-prioridade').value = btn.dataset.prioridade;
        document.getElementById('edit-status').value     = btn.dataset.status;
        document.getElementById('edit-membro').value     = btn.dataset.membro;

        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        document.getElementById('edit-descricao').focus();
    }

    function fecharModal() {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.btn-editar').forEach(btn => {
        btn.addEventListener('click', () => abrirModal(btn));
    });

    document.getElementById('modal-fechar').addEventListener('click', fecharModal);
    document.getElementById('modal-cancelar').addEventListener('click', fecharModal);
    modal.addEventListener('click', e => { if (e.target === modal) fecharModal(); });
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && modal.style.display !== 'none') fecharModal();
    });

    // ===== EXCLUSÃO COM CONFIRMAÇÃO =====
    document.querySelectorAll('.btn-excluir').forEach(btn => {
        btn.addEventListener('click', function () {
            const url = this.dataset.href;
            if (!url) return;

            // Modal de confirmação customizado (inline, sem depender do app.js)
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:10000;';
            overlay.innerHTML = `
                <div style="background:#1a0a3e;border:1px solid rgba(231,76,60,.4);border-radius:16px;padding:32px;max-width:360px;width:90%;text-align:center;color:#fff;box-shadow:0 12px 40px rgba(0,0,0,.5);">
                    <div style="font-size:2.2rem;margin-bottom:12px;">🗑️</div>
                    <h3 style="margin-bottom:8px;font-size:1.1rem;">Excluir atividade?</h3>
                    <p style="color:rgba(255,255,255,.65);font-size:.9rem;margin-bottom:24px;line-height:1.5;">Esta ação não pode ser desfeita.</p>
                    <div style="display:flex;gap:12px;justify-content:center;">
                        <button id="fh-confirm-sim" style="background:#e74c3c;color:#fff;border:none;padding:10px 28px;border-radius:8px;cursor:pointer;font-weight:700;font-size:.95rem;">Sim, excluir</button>
                        <button id="fh-confirm-nao" style="background:rgba(255,255,255,.12);color:#fff;border:none;padding:10px 28px;border-radius:8px;cursor:pointer;font-size:.95rem;">Cancelar</button>
                    </div>
                </div>
            `;

            document.body.appendChild(overlay);

            overlay.querySelector('#fh-confirm-sim').addEventListener('click', () => {
                window.location.href = url;
            });

            const fechar = () => overlay.remove();
            overlay.querySelector('#fh-confirm-nao').addEventListener('click', fechar);
            overlay.addEventListener('click', e => { if (e.target === overlay) fechar(); });
            document.addEventListener('keydown', function esc(e) {
                if (e.key === 'Escape') { fechar(); document.removeEventListener('keydown', esc); }
            });
        });
    });
})();
</script>

</body>
</html>
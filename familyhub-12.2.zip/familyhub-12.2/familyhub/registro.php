<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "includes/funcoes.php";

if (usuarioLogado()) {
    header("Location: index.php");
    exit;
}

$formNome  = isset($_SESSION['form_nome'])  ? esc($_SESSION['form_nome'])  : '';
$formEmail = isset($_SESSION['form_email']) ? esc($_SESSION['form_email']) : '';
unset($_SESSION['form_nome'], $_SESSION['form_email']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - FamilyHub+</title>
    <link rel="stylesheet" href="css/style.css">    <script>
        (function(){
            var t = localStorage.getItem('fh-theme');
            var dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', t || (dark ? 'dark' : 'light'));
        })();
    </script>
</head>
<body class="login-body">

<div class="login-container">
    <div class="login-box">
        <div class="login-header">
            <h1>FamilyHub+</h1>
            <p>Crie sua conta e organize sua família</p>
        </div>

        <?= exibirAlertas() ?>

        <form action="acoes/registrar.php" method="POST" class="login-form" id="formRegistro">
            <div class="form-group">
                <label for="nome">Nome da família *</label>
                <input type="text" id="nome" name="nome" placeholder="Silva" required minlength="3" maxlength="100" value="<?= $formNome ?>">
                <small class="form-hint">Mínimo 3 caracteres</small>
            </div>

            <div class="form-group">
                <label for="email">Email *</label>
                <input type="email" id="email" name="email" placeholder="seu@email.com" required maxlength="150" value="<?= $formEmail ?>">
            </div>

            <div class="form-group">
                <label for="senha">Senha *</label>
                <input type="password" id="senha" name="senha" placeholder="••••••••" required minlength="6" maxlength="255">
                <small class="form-hint">Mínimo 6 caracteres</small>
                <div id="passwordStrength"></div>
            </div>

            <div class="form-group">
                <label for="confirmar_senha">Confirmar Senha *</label>
                <input type="password" id="confirmar_senha" name="confirmar_senha" placeholder="••••••••" required minlength="6" maxlength="255">
                <small class="form-hint" id="passwordMatch"></small>
            </div>

            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="termos" required>
                    <span>Aceito os <a href="termos.php" target="_blank">termos de uso</a> e a <a href="privacidade.php" target="_blank">política de privacidade</a></span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Criar Conta</button>
        </form>

        <div class="login-footer">
            <p>Já tem uma conta? <a href="login.php">Faça login</a></p>
        </div>
    </div>
</div>

<script>
const senha          = document.getElementById('senha');
const confirmarSenha = document.getElementById('confirmar_senha');
const strength       = document.getElementById('passwordStrength');
const match          = document.getElementById('passwordMatch');

senha.addEventListener('input', function () {
    const v = this.value;
    if (!v) { strength.innerHTML = ''; return; }
    let s = 0;
    if (v.length >= 6) s++;
    if (v.length >= 8) s++;
    if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++;
    if (/[0-9]/.test(v)) s++;
    if (/[^a-zA-Z0-9]/.test(v)) s++;
    const labels = ['', 'Senha fraca', 'Senha fraca', 'Senha média', 'Senha forte', 'Senha forte'];
    const colors = ['', '#f56565', '#f56565', '#ed8936', '#48bb78', '#48bb78'];
    strength.innerHTML = `<small style="color:${colors[s]}">⚡ ${labels[s]}</small>`;
});

confirmarSenha.addEventListener('input', function () {
    if (!this.value) { match.textContent = ''; return; }
    if (this.value === senha.value) {
        match.textContent = '✔ Senhas coincidem';
        match.style.color = '#48bb78';
    } else {
        match.textContent = '✖ Senhas não coincidem';
        match.style.color = '#f56565';
    }
});

document.getElementById('formRegistro').addEventListener('submit', function (e) {
    if (senha.value !== confirmarSenha.value) {
        e.preventDefault();
        alert('As senhas não coincidem!');
        confirmarSenha.focus();
    }
});
</script>

</body>
</html>

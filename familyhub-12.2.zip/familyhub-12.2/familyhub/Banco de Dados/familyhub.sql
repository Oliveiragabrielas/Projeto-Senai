-- Cria o banco de dados
create DATABASE familyhub

-- Abrir a tabela familyhub
USE familyhub;

-- Cria tabela de usuarios 
create table usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- cria a tabela dos membros da família
create table membros (
    id_membro INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    papel VARCHAR(50) NOT NULL,
    data_nascimento DATE,
    id_usuario INT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_membro_usuario
    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
);

-- Cria a tabela de atividades
create table atividades (
    id_ativ INT AUTO_INCREMENT PRIMARY KEY,
    descricao TEXT NOT NULL,
    tipo ENUM('Escolar', 'Esporte', 'Social', 'Casa', 'Saude' , 'Outro' ) NOT NULL,
    data DATE NOT NULL,
    horario TIME NOT NULL,
    prioridade ENUM('Baixa', 'Média', 'Alta') DEFAULT 'Média',
    status ENUM('Pendente', 'Processo', 'Concluída') DEFAULT 'Pendente',
    id_membro INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_atividade_membro
    FOREIGN KEY (id_membro)
    REFERENCES membros(id_membro)
    ON DELETE CASCADE
);

-- Criar tabela de notificação
create table notificacoes (
    id_notificacao INT AUTO_INCREMENT PRIMARY KEY,
    mensagem TEXT NOT NULL,
    lida BOOLEAN DEFAULT FALSE,
    id_usuario INT NOT NULL,
    criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id_usuario)
    ON DELETE CASCADE
);

-- ============================================================
-- ATUALIZAÇÃO v3.1 - Seleção de Perfil por Membro
-- ============================================================
-- Nenhuma alteração de schema é necessária.
-- A seleção de membro ativo é controlada via session PHP:
--   $_SESSION['membro_id']    = id do membro ativo
--   $_SESSION['membro_nome']  = nome do membro ativo
--   $_SESSION['membro_papel'] = papel do membro ativo
--
-- Fluxo: Login → escolher_membro.php → acoes/entrar_como.php → index.php
-- Troca:  Menu (botão "Trocar perfil") ou membros.php ("Entrar como")

-- ============================================================
-- ATUALIZAÇÃO v4.0 - Sistema de Pontuação (Ranking)
-- ============================================================

-- Tabela de pontuação por membro
CREATE TABLE IF NOT EXISTS pontuacao (
    id_pontuacao INT AUTO_INCREMENT PRIMARY KEY,
    id_membro INT NOT NULL,
    id_ativ INT NOT NULL,
    pontos INT NOT NULL DEFAULT 0,
    motivo VARCHAR(100) NOT NULL DEFAULT 'Atividade concluída',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (id_membro) REFERENCES membros(id_membro) ON DELETE CASCADE,
    FOREIGN KEY (id_ativ)   REFERENCES atividades(id_ativ) ON DELETE CASCADE,
    UNIQUE KEY uq_membro_ativ (id_membro, id_ativ)
);
-- Pontos por prioridade: Alta=30, Média=20, Baixa=10

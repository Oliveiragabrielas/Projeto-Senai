<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('FAMILYHUB_SESSION');
    session_start();
}

$_SESSION = [];

if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 42000, '/');
}

session_destroy();
header("Location: login.php");
exit;

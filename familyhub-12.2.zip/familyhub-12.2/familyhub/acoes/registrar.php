<?php
/**
 * Ação de Registro - FamilyHub+
 * IMPORTANTE: A tabela usuarios NÃO tem coluna telefone.
 * O campo é coletado no formulário mas não salvo no banco.
 */

// Configurar sessão ANTES de session_start()
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/conexao.php";
require_once "../includes/funcoes.php";

if (usuarioLogado()) {
    header("Location: ../index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../registro.php");
    exit;
}

// Receber dados
$nome            = trim($_POST['nome'] ?? '');
$email           = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '');
$senha           = $_POST['senha'] ?? '';
$confirmar_senha = $_POST['confirmar_senha'] ?? '';
$termos          = isset($_POST['termos']);

// Guardar na sessão para repopular formulário em caso de erro
$_SESSION['form_nome']  = $nome;
$_SESSION['form_email'] = $email;

$erros = [];

// Validar nome
if (empty($nome)) {
    $erros[] = "O nome é obrigatório.";
} elseif (strlen($nome) < 3) {
    $erros[] = "O nome deve ter pelo menos 3 caracteres.";
} elseif (strlen($nome) > 100) {
    $erros[] = "O nome não pode ter mais de 100 caracteres.";
}

// Validar email
if (empty($email)) {
    $erros[] = "O email é obrigatório.";
} elseif (!validarEmail($email)) {
    $erros[] = "Email inválido.";
} elseif (strlen($email) > 150) {
    $erros[] = "Email muito longo.";
}

// Validar senha
if (empty($senha)) {
    $erros[] = "A senha é obrigatória.";
} elseif (strlen($senha) < 6) {
    $erros[] = "A senha deve ter pelo menos 6 caracteres.";
}

// Validar confirmação de senha
if ($senha !== $confirmar_senha) {
    $erros[] = "As senhas não coincidem.";
}

// Validar termos
if (!$termos) {
    $erros[] = "Você deve aceitar os termos de uso.";
}

if (!empty($erros)) {
    setMensagem('erro', implode("<br>", $erros));
    header("Location: ../registro.php");
    exit;
}

try {
    // Verificar email duplicado
    $stmtCheck = $conn->prepare("SELECT id_usuario FROM usuarios WHERE email = ? LIMIT 1");
    if (!$stmtCheck) throw new Exception("Prepare falhou: " . $conn->error);
    $stmtCheck->bind_param("s", $email);
    $stmtCheck->execute();
    if ($stmtCheck->get_result()->num_rows > 0) {
        $stmtCheck->close();
        setMensagem('erro', "Este email já está cadastrado. <a href='../login.php'>Faça login</a>");
        header("Location: ../registro.php");
        exit;
    }
    $stmtCheck->close();

    // Inserir usuário — tabela tem: id_usuario, nome, email, senha, data_criacao
    $senha_hash = hashSenha($senha);
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
    if (!$stmt) throw new Exception("Prepare falhou: " . $conn->error);
    $stmt->bind_param("sss", $nome, $email, $senha_hash);
    if (!$stmt->execute()) throw new Exception("Execute falhou: " . $stmt->error);
    $id_usuario = $stmt->insert_id;
    $stmt->close();

    // Notificação de boas-vindas
    $msg_bv = "Bem-vindo(a) ao FamilyHub+, {$nome}! Comece cadastrando os membros da sua família.";
    $stmtN = $conn->prepare("INSERT INTO notificacoes (mensagem, id_usuario) VALUES (?, ?)");
    if ($stmtN) {
        $stmtN->bind_param("si", $msg_bv, $id_usuario);
        $stmtN->execute();
        $stmtN->close();
    }

    // Limpar sessão do formulário e fazer login automático
    unset($_SESSION['form_nome'], $_SESSION['form_email']);
    $_SESSION['usuario_id']   = $id_usuario;
    $_SESSION['usuario_nome'] = $nome;
    session_regenerate_id(true);

    setMensagem('sucesso', "Conta criada com sucesso! Bem-vindo(a) ao FamilyHub+! 🎉");
    header("Location: ../index.php");
    exit;

} catch (Exception $e) {
    logErro("Erro ao registrar: " . $e->getMessage());
    setMensagem('erro', "Erro ao criar conta. Tente novamente.");
    header("Location: ../registro.php");
    exit;
}

<?php
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', 7200);
    session_name('FAMILYHUB_SESSION');
    session_start();
}

require_once "../includes/verifica_login.php";
require_once "../includes/conexao.php";

$id_usuario = (int)$_SESSION['usuario_id'];
$id_ativ    = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id_ativ <= 0) {
    header("Location: ../atividades.php?status=erro");
    exit;
}

// Verifica se a atividade pertence a um membro do usuário logado (segurança)
$stmt = $conn->prepare("
    SELECT a.id_ativ 
    FROM atividades a
    INNER JOIN membros m ON a.id_membro = m.id_membro
    WHERE a.id_ativ = ? AND m.id_usuario = ?
");

if (!$stmt) {
    header("Location: ../atividades.php?status=erro");
    exit;
}

$stmt->bind_param("ii", $id_ativ, $id_usuario);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    // Atividade não encontrada ou não pertence ao usuário
    $stmt->close();
    header("Location: ../atividades.php?status=erro");
    exit;
}
$stmt->close();

// Buscar nome da atividade antes de excluir (para notificação)
$descAtiv = '';
$stmtDesc = $conn->prepare("SELECT descricao FROM atividades WHERE id_ativ = ?");
if ($stmtDesc) {
    $stmtDesc->bind_param("i", $id_ativ);
    $stmtDesc->execute();
    $rowDesc = $stmtDesc->get_result()->fetch_assoc();
    $descAtiv = $rowDesc['descricao'] ?? 'atividade';
    $stmtDesc->close();
}

// Exclui a atividade
$del = $conn->prepare("DELETE FROM atividades WHERE id_ativ = ?");

if (!$del) {
    header("Location: ../atividades.php?status=erro");
    exit;
}

$del->bind_param("i", $id_ativ);

if ($del->execute()) {
    $del->close();

    // Notificação de exclusão
    require_once "../includes/funcoes.php";
    $autorNome  = $_SESSION['membro_nome']  ?? $_SESSION['usuario_nome'] ?? 'Alguém';
    $autorPapel = $_SESSION['membro_papel'] ?? '';
    $autorInfo  = $autorPapel ? "$autorNome ($autorPapel)" : $autorNome;
    $msg = "🗑️ $autorInfo excluiu a atividade \"$descAtiv\"";
    $sn = $conn->prepare("INSERT INTO notificacoes (mensagem, id_usuario) VALUES (?, ?)");
    if ($sn) {
        $sn->bind_param("si", $msg, $id_usuario);
        $sn->execute();
        $sn->close();
    }

    header("Location: ../atividades.php?status=excluido");
} else {
    $del->close();
    header("Location: ../atividades.php?status=erro");
}
exit;